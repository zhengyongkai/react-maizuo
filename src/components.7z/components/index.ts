import TButton from "./KButton/KButton";

export default {
  TButton,
};
