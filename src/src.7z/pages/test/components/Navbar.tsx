import { useSelector } from "react-redux";
import Style from "../css/navbar.module.scss";

export default function Navbar() {
  const selector = useSelector((state) => {
    return state.user.user.username;
  });
  return (
    <>
      <div className={Style.navbar}>欢迎你 {selector}</div>
    </>
  );
}
