export default function myPage() {
  return <>my</>;
}
