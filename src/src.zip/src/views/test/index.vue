<template>
  <div>
    <h3>测试页面</h3>
    <div id="main"></div>
  </div>
</template>

<script setup>
import china from "./data.js";
import * as echarts from "echarts";

function init() {
  nextTick(() => {
    console.log("china", china);

    // 基于准备好的dom，初始化echarts实例
    var myChart = echarts.init(document.getElementById("main"));
    echarts.registerMap("china", china);
    // 使用刚指定的配置项和数据显示图表。
    // 设置地图配置项
    const option = {
      tooltip: {
        trigger: "item",
        formatter: "{b}：{c}"
      },
      series: [
        {
          name: "数据",
          type: "map",
          map: "china",
          roam: true,
          label: {
            show: true
          },
          data: [
            { name: "合肥市", value: 100 },
            { name: "六安", value: 200 }
            // 其他城市的数据...
          ]
        }
      ]
    };
    myChart.setOption(option);
  });
}
init();
</script>

<style lang='scss' scoped>
#main {
  width: 100%;
  height: 500px;
}
</style>