<template>
  <div class="social_container">
    <div class="social_container_main">
      <el-tabs v-model="activeName" @tab-click="tabChange">
        <el-tab-pane :label="$t('sign.tab1')" :name="$t('sign.tab1')">
          <template #label>
            <div class="custom-tabs-label">
              <svg-icon icon-class="tab1" />
              <span>{{$t('sign.tab1')}}</span>
            </div>
          </template>
          <div v-for="(sys,index) in signlist" :key="index" class="sys">
            <div class="sys_header">
              <span>{{sys.systype}} {{$t('sign.sys')}}</span>
              <div class="mark">{{sys.total}}</div>
            </div>
            <div class="sys_form">
              <div
                v-for="(form,i) in sys.form"
                :key="i"
                class="form_item"
                @click="formItemClick(sys,form)"
              >
                <div class="form_item_title">{{form.formname}}</div>
                <div class="form_item_body">
                  <img src="@/assets/images/todo.png" alt />
                  <div>
                    <div>
                      {{form.acount}}
                      <br />
                      {{$t('sign.content')}}
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <el-empty :image-size="200" v-if="signlist.length <= 0" />
        </el-tab-pane>
        <el-tab-pane :label="$t('sign.tab2')" :name="$t('sign.tab2')">
          <template #label>
            <div class="custom-tabs-label">
              <svg-icon icon-class="tab2" />
              <span>{{$t('sign.tab2')}}</span>
            </div>
          </template>
          <el-table
            v-loading="loading"
            :data="formList"
            style="width: 100%;"
            @selection-change="handleSelectionChange"
          >
            <el-table-column type="selection" width="55" align="center" />
            <el-table-column
              :label="$t('sign.docName')"
              align="center"
              prop="formname"
              :show-overflow-tooltip="true"
            />
            <el-table-column
              :label="$t('sign.docNo')"
              align="center"
              prop="id"
              :show-overflow-tooltip="true"
            />
            <el-table-column
              :label="$t('sign.lastSignTime')"
              align="center"
              prop="lasttransactiondate"
              :show-overflow-tooltip="true"
            />
            <el-table-column
              :label="$t('sign.signNode')"
              align="center"
              prop="nodename"
              :show-overflow-tooltip="true"
            />
            <el-table-column
              :label="$t('sign.creater')"
              align="center"
              prop="approver"
              :show-overflow-tooltip="true"
            />

            <el-table-column
              :label="$t('sign.option')"
              align="center"
              class-name="small-padding fixed-width"
              width="100"
            >
              <template #default="scope">
                <!-- <div>查看</div> -->
                <el-button
                  link
                  type="primary"
                  icon="Document"
                  @click="handleForm(scope.row)"
                >{{$t('sign.view')}}</el-button>
              </template>
            </el-table-column>
          </el-table>
        </el-tab-pane>
        <el-tab-pane :label="$t('sign.tab3')" :name="$t('sign.tab3')">
          <template #label>
            <div class="custom-tabs-label">
              <svg-icon icon-class="tab3" />
              <span>{{$t('sign.tab3')}}</span>
            </div>
          </template>
          <myApply />
        </el-tab-pane>
      </el-tabs>
      <!-- <el-button type="primary" plain>Primary</el-button> -->
      <el-row :gutter="10" class="mb8" style="margin-top:20px" v-if="activeName == $t('sign.tab2')">
        <el-col :span="1.5">
          <el-button
            type="primary"
            plain
            :disabled="submitDisabled"
            @click="open = true ;signObj.action = ['Y']"
          >{{$t('sign.batchSign')}}</el-button>
        </el-col>
        <el-col :span="1.5">
          <el-button
            type="danger"
            plain
            :disabled="submitDisabled"
            @click="open = true;signObj.action = ['N']"
          >{{$t('sign.batchReject')}}</el-button>
        </el-col>
      </el-row>
    </div>

    <el-dialog :title="$t('sign.title')" v-model="open" width="600px" append-to-body>
      <el-input v-model="comment" placeholder type="textarea" :rows="5" />
      <template #footer>
        <div class="dialog-footer">
          <el-button type="primary" @click="submit">{{$t('sign.confirm')}}</el-button>
          <el-button @click="open = false">{{$t('sign.cancel')}}</el-button>
        </div>
      </template>
    </el-dialog>
  </div>
</template>

<script setup>
import { getSignTotal, getSignList, batchSign } from "@/api/social/sign";
import useUserStore from "@/store/modules/user";
import myApply from "./component/myApply";
const { proxy } = getCurrentInstance();
import { useLang } from "@/utils/lang.js";

const user = useUserStore();
const signlist = ref([]);
const formList = ref([]);
const loading = ref(false);
let list = [];
let objList = [];
const selectedSystem = ["112", "101"];
const activeName = ref("");
const submitDisabled = ref(true);
const comment = ref("");
const open = ref(false);
const signObj = ref({});
function init() {
  activeName.value = proxy.$t("sign.tab1");
  //   console.log("user", user.userName);
  //   selectedSystem.forEach(item => {
  //     getSignTotal({
  //       username: user.userName,
  //       selectedSystem: item,
  //       lang: "zh"
  //     }).then(res => {
  //       if (res.data) {
  //         // res.data[0].form = res.data[0].form
  //         //   .concat(res.data[0].form)
  //         //   .concat(res.data[0].form);
  //         list = list.concat(res.data);
  //         signlist.value = list;
  //         // console.log("signlist", signlist.value);
  //       }
  //     });
  //   });

  getSignTotal({
    username: user.userName,
    selectedSystem: selectedSystem.join(","),
    lang: "zh"
  }).then(res => {
    if (res.data) {
      // res.data[0].form = res.data[0].form
      //   .concat(res.data[0].form)
      //   .concat(res.data[0].form);
      list = list.concat(res.data);
      signlist.value = list;
      // console.log("signlist", signlist.value);
    }
  });
}

function detailInit(obj) {
  objList = [];
  if (obj) {
    loading.value = true;
    getSignList({
      username: user.userName,
      lang: "zh",
      systype: obj.systype,
      formtype: obj.formtype,
      page: 1,
      limit: 999
    }).then(res => {
      res.data.form.map(item => {
        item.systype = obj.systype;
      });
      formList.value = res.data.form;
      loading.value = false;
    });
  } else {
    var calcNum = { total: 0, num: 0, sysNum: 0 };
    var sysForm = [];
    loading.value = true;
    selectedSystem.forEach(item => {
      getSignTotal({
        username: user.userName,
        selectedSystem: item,
        lang: "zh"
      }).then(res => {
        calcNum.sysNum++;

        if (res.data && res.data.length > 0) {
          var form = res.data[0].form;
          form.forEach(i => {
            i.systype = res.data[0].systype;
          });

          sysForm = sysForm.concat(form);
          calcNum.total += res.data[0].total;
        }

        if (calcNum.sysNum == selectedSystem.length) {
          sysForm.forEach(it => {
            getSignList({
              username: user.userName,
              lang: "zh",
              systype: it.systype,
              formtype: it.formtype,
              page: 1,
              limit: 999
            }).then(request => {
              calcNum.num += request.data.form.length;
              request.data.form.map(item => {
                item.systype = it.systype;
              });
              objList = objList.concat(request.data.form);

              if (calcNum.total == calcNum.num) {
                formList.value = objList;
                loading.value = false;
              }
            });
          });
        }
      });
    });
  }
}
function tabChange(val) {
  //   signlist.value = [];
  formList.value = [];
  list = [];
  objList = [];
  if (val.paneName == "待审核汇总") {
    init();
  } else {
    detailInit();
  }
}
function formItemClick(sys, form) {
  //   console.log(sys, form);
  let obj = {};
  obj.systype = sys.systype;
  obj.formtype = form.formtype;
  activeName.value = "待审核明细";
  detailInit(obj);
}

function handleForm(row) {
  //   console.log(row);
  if (row.url) {
    window.open(row.url, "_block");
  }
}

function handleSelectionChange(selection) {
  //   console.log("selection", selection);
  //   ids.value = selection.map(item => item.id);
  var list = selection.filter(item => item.isbatch == "N");
  submitDisabled.value = !checkRepeat(selection, "systype") || list.length > 0;
  if (checkRepeat(selection, "systype")) {
    signObj.value.systype = checkRepeat(selection, "systype");
    signObj.value.id = selection.map(item => item.id);
    signObj.value.nodecode = selection.map(item => item.nodecode);
    signObj.value.formtype = selection[0].formtype;
  }
}

function checkRepeat(arr, val) {
  const isSame = arr.reduce((prev, curr) => {
    if (prev === false) {
      return false;
    }
    if (prev === null) {
      return curr[val];
    }
    if (prev !== curr[val]) {
      return false;
    }
    return prev;
  }, null);
  return isSame;
}

function submit() {
  signObj.value.comment = [comment.value];
  signObj.value.userid = user.userName;
  //   signObj.value.fileid = [];
  //   console.log("signObj", signObj.value);
  batchSign(signObj.value).then(res => {
    // console.log("res", res);
    open.value = false;
    proxy.$modal.msgSuccess(res.msg);
    tabChange("待审核汇总");
  });
}

init();
</script>

<style lang='scss' scoped>
.mark {
  color: #fff;
  padding: 0 4px;
  background-color: red;
  border-radius: 3px;
}
.sys {
  margin-bottom: 30px;
}
.sys_header {
  display: flex;
  justify-content: flex-start;
  align-items: center;
  margin-bottom: 20px;
  span {
    color: #409eff;
    margin-right: 10px;
  }
}

.sys_form {
  display: flex;
  justify-content: flex-start;
  align-items: center;
  flex-wrap: wrap;
  cursor: pointer;

  .form_item {
    // border-left: 1px solid black;
    // border-right: 1px solid black;
    // border-bottom: 1px solid black;
    border: 1px solid black;

    margin: 0 15px 30px 15px;
    border-radius: 5px;
    width: calc((100% - 120px) / 4);

    img {
      width: 40px;
      height: 40px;
      margin-right: 10px;
    }

    &:hover {
      transform: scale(1.1);
    }
  }
}

.form_item_title {
  //   position: absolute;
  //   top: 0;
  //   left: 20px;
  padding: 0 10px;
  margin: 0 20px;
  display: inline-block;
  transform: translateY(-10px);
  background-color: #fff;
  position: relative;
}

.form_item_body {
  display: flex;
  justify-content: center;
  align-items: center;
  position: relative;
  padding: 10px 40px 30px;
  text-align: center;
}
</style>