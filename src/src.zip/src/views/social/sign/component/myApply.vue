<template>
  <div>
    <div v-for="(sys,index) in sysList" :key="index" class="sys">
      <div class="sys_header">
        <span>{{sys.serverAlias}} {{$t('sign.sys')}}</span>
        <!-- <div class="mark">{{sys.total}}</div> -->
      </div>
      <!-- <div class="sys_form">
        <div
          v-for="(form,i) in sys.forms"
          :key="i"
          class="form_item"
          @click="formItemClick(sys,form)"
        >
          <div class="form_item_title">{{i}}</div>
          <div class="form_item_body">
            <img src="@/assets/images/todo.png" alt />
            <div>
              <div>我的申请单</div>
            </div>
          </div>
        </div>
      </div>-->
      <div style="display:flex;flex-wrap: wrap;">
        <div v-for="(forms,i) in sys.forms" :key="i" style="display:flex;flex-wrap: wrap;">
          <!-- <el-link
            v-for="(form,n) in forms"
            :key="n"
            style="margin-left:20px;margin-top:10px"
            @click="formItemClick(sys,form)"
          >{{form.formName}}</el-link>-->
          <el-check-tag
            v-for="(form,n) in forms"
            :key="n"
            class="ml-2"
            type="info"
            size="large"
            :checked="false"
            style="margin-left:20px;margin-top:10px"
            @click="formItemClick(sys,form)"
          >{{useLang(form,'formName')}}</el-check-tag>
        </div>
      </div>
    </div>
    <el-empty :image-size="200" v-if="sysList.length <= 0" />
  </div>
</template>

<script setup>
import { getMainPlatForm, listForm } from "@/api/tps/platform";
const { proxy } = getCurrentInstance();
import { useLang } from "@/utils/lang.js";

const sysList = ref([]);

function init() {
  getMainPlatForm().then(res => {
    sysList.value = res.data;
  });
}

function formItemClick(sys, form) {
  // console.log("sys", sys, form);
  if (form.myFormUrl) {
    // window.open(form.myFormUrl, "_blank");
    window.open(form.myFormUrl, "_block");
  } else {
    proxy.$modal.msgError("未配置该系统我的申请单地址。");
  }
}
init();
</script>

<style lang='scss' scoped>
.sys {
  margin-bottom: 30px;
}
.sys_header {
  display: flex;
  justify-content: flex-start;
  align-items: center;
  margin-bottom: 20px;
  span {
    color: #409eff;
    margin-right: 10px;
  }
}

.sys_form {
  display: flex;
  justify-content: flex-start;
  align-items: center;
  flex-wrap: wrap;
  cursor: pointer;

  .form_item {
    // border-left: 1px solid black;
    // border-right: 1px solid black;
    // border-bottom: 1px solid black;
    border: 1px solid black;

    margin: 0 15px 30px 15px;
    border-radius: 5px;
    width: calc((100% - 120px) / 4);

    img {
      width: 40px;
      height: 40px;
      margin-right: 10px;
    }

    &:hover {
      transform: scale(1.1);
    }
  }
}
.form_item_title {
  //   position: absolute;
  //   top: 0;
  //   left: 20px;
  padding: 0 10px;
  margin: 0 20px;
  display: inline-block;
  transform: translateY(-10px);
  background-color: #fff;
  position: relative;
}

.form_item_body {
  display: flex;
  justify-content: center;
  align-items: center;
  position: relative;
  padding: 10px 40px 30px;
  text-align: center;
}
</style>