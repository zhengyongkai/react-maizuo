<template>
  <div class="social_container_content_main_item" v-if="style === 'list'">
    <div class="social_container_content_main_item_top">
      <img src="@/assets/images/social/supernotes.png" />
      <div>
        <div>
          <div>Super Notes郵箱申請</div>
          <div class="social_container_content_main_item_advance">
            <span>前往</span> <img src="@/assets/images/social/right.png" />
          </div>
        </div>
        <div>資安防禦</div>
      </div>
    </div>
    <div class="social_container_content_main_item_desc">
      集團員工個人郵箱使用申請集團員工個人郵箱使用申個
    </div>
  </div>
  <div class="social_container_content_main_item_tile" v-if="style === 'tile'">
    <div class="social_container_content_main_item_top">
      <img src="@/assets/images/social/supernotes.png" />
      <div>
        <div>
          <div>Super Notes郵箱申請</div>
          <div>資安防禦</div>
        </div>
        <div class="social_container_content_main_item_desc">
          集團員工個人郵箱使用申請集團員工個人郵箱使用申個
        </div>
      </div>
    </div>

    <div class="social_container_content_main_item_advance">
      <span>前往</span> <img src="@/assets/images/social/right.png" />
    </div>
  </div>
</template>

<script setup>
const props = defineProps({
  style: {
    type: String,
    default: 'list'
  }
})
const emit = defineEmits('tabChange')
</script>

<style lang="scss" scoped>
.social_container_content_main_item {
  padding: 16px 14px 16px 16px;
  cursor: pointer;
  border-radius: 4px;
  box-sizing: inherit;
  height: 118px;
  background: linear-gradient(186.12deg, #f1f7ff 1.79%, #f7faff 78.56%);
  &:hover {
    background: linear-gradient(96.79deg, #d3e6ff 1.6%, #ffffff 90.87%);
    box-shadow: 0px 6px 15px 0px #0000001a;
    .social_container_content_main_item_advance {
      display: block !important;
    }
  }

  .social_container_content_main_item_top {
    height: 48px;
    display: flex;
    > img {
      height: 48px;
      // width: 48px;
      margin-right: 16px;
    }
    > div {
      flex: 1;

      > :first-child {
        font-size: 14px;
        font-weight: 700;
        line-height: 22px;
        letter-spacing: 0em;
        text-align: left;
        display: flex;

        > :first-child {
        }
        > :last-child {
          color: #3260c9;
          display: none;
          text-align: right;
          margin-left: auto;
          img {
            width: 12px;
            height: 8px;
          }
        }
      }

      > :last-child {
        height: 22px;
        background-color: #fff;
        font-size: 12px;
        font-weight: 700;
        line-height: 18px;
        letter-spacing: 0em;
        text-align: left;
        width: 64px;
        padding: 2px 8px;
        border-radius: 4px;
        color: #3260c9;
        margin-top: 4px;
      }
    }
  }
  .social_container_content_main_item_desc {
    font-size: 14px;
    font-weight: 400;
    line-height: 22px;
    letter-spacing: 0em;
    text-align: left;
    color: #727272;
    margin-top: 16.89px;
  }
}
.social_container_content_main_item_tile {
  width: 100%;
  padding: 16px 8px 16px 16px;
  border-bottom: 1px solid #ebf4ff;
  display: flex;
  align-items: center;
  .social_container_content_main_item_top {
    display: flex;
    align-items: center;
    > img {
      height: 48px;
      // width: 48px;
      margin-right: 16px;
    }
    > div {
      > div {
        display: flex;
        > :first-child {
          font-size: 14px;
          font-weight: 700;
          //   line-height: 22px;
          letter-spacing: 0em;
          text-align: left;
          color: #333333;
        }
        > :last-child {
          height: 22px;
          background-color: #f0f4ff;
          font-size: 12px;
          font-weight: 700;
          line-height: 18px;
          letter-spacing: 0em;
          text-align: left;
          width: 64px;
          padding: 2px 8px;
          border-radius: 4px;
          color: #3260c9;
          margin-left: 8px;
          //   margin-top: 4px;
        }
      }
    }

    .social_container_content_main_item_desc {
      margin-top: 6px;
      font-size: 14px;
      font-weight: 400;
      line-height: 22px;
      letter-spacing: 0em;
      text-align: left;
      color: #727272;
    }
  }

  &:hover {
    background-color: #ebf4ff;
    // box-shadow: 0px 6px 15px 0px #0000001a;
  }

  .social_container_content_main_item_advance {
    margin-left: auto;
    color: #3260c9;
    display: block;
    text-align: right;
    margin-left: auto;
    font-size: 12px;
    font-weight: 700;
    line-height: 18px;
    letter-spacing: 0em;
    text-align: left;

    img {
      //   width: 12px;
      height: 8px;
      margin-left: 8px;
    }
  }
}
</style>
