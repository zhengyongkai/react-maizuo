<template>
  <div class="search_popover">
    <div>搜索記錄</div>
    <div class="search_popover_items">
      <div class="search_popover_item">
        <img src="@/assets/images/social/history.png" />
        <div>網路</div>
        <img src="@/assets/images/social/search-close.png" />
      </div>
      <div class="search_popover_item">
        <img src="@/assets/images/social/history.png" />
        <div>網路</div>
        <img src="@/assets/images/social/search-close.png" />
      </div>
      <div class="search_popover_item">
        <img src="@/assets/images/social/history.png" />
        <div>網路</div>
        <img src="@/assets/images/social/search-close.png" />
      </div>
    </div>
  </div>
</template>

<style scoped lang="scss"></style>
