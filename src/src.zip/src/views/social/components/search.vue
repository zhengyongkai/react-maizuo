<template>
  <div class="social_container_header_content">
    <div class="social_container_header_title">搜尋您想要申請的服務</div>
    <div class="social_container_search_content">
      <div class="social_container_search" id="social_container_search">
        <input
          class="social_search_input"
          type="text"
          placeholder="請輸入關鍵字"
          v-model.trim="input"
        />
        <div>
          <img
            class="ic_close"
            v-if="input"
            @click="input = ''"
            src="@/assets/images/social/search-close.png"
          />
          <button @click="search">
            <img src="@/assets/images/social/hot_search.svg" />
          </button>
        </div>
      </div>
      <div class="social_container_hot">
        <span>热门搜寻：</span>
        <span>O365，</span>
        <span>移动办公，</span>
        <span>WIFI，</span>
        <span>资安范围</span>
      </div>
      <teleport :to="'#social_container_search'" v-if="mounted">
        <div class="search_popover" :style="focus ? 'max-height:400px;' : 'max-height:0;'">
          <div>搜索記錄</div>
          <div class="search_popover_items">
            <div class="search_popover_item">
              <img src="@/assets/images/social/history.png" />
              <div>網路</div>
              <img src="@/assets/images/social/search-close.png" />
            </div>
            <div class="search_popover_item">
              <img src="@/assets/images/social/history.png" />
              <div>網路</div>
              <img src="@/assets/images/social/search-close.png" />
            </div>
            <div class="search_popover_item">
              <img src="@/assets/images/social/history.png" />
              <div>網路</div>
              <img src="@/assets/images/social/search-close.png" />
            </div>
            <div class="search_popover_item">
              <img src="@/assets/images/social/history.png" />
              <div>網路</div>
              <img src="@/assets/images/social/search-close.png" />
            </div>
            <div class="search_popover_item">
              <img src="@/assets/images/social/history.png" />
              <div>網路</div>
              <img src="@/assets/images/social/search-close.png" />
            </div>
            <div class="search_popover_item">
              <img src="@/assets/images/social/history.png" />
              <div>網路</div>
              <img src="@/assets/images/social/search-close.png" />
            </div>
            <div class="search_popover_item">
              <img src="@/assets/images/social/history.png" />
              <div>網路</div>
              <img src="@/assets/images/social/search-close.png" />
            </div>
            <div class="search_popover_item">
              <img src="@/assets/images/social/history.png" />
              <div>網路</div>
              <img src="@/assets/images/social/search-close.png" />
            </div>
            <div class="search_popover_item">
              <img src="@/assets/images/social/history.png" />
              <div>網路</div>
              <img src="@/assets/images/social/search-close.png" />
            </div>
            <div class="search_popover_item">
              <img src="@/assets/images/social/history.png" />
              <div>網路</div>
              <img src="@/assets/images/social/search-close.png" />
            </div>
            <div class="search_popover_item">
              <img src="@/assets/images/social/history.png" />
              <div>網路</div>
              <img src="@/assets/images/social/search-close.png" />
            </div>
          </div>
        </div>
      </teleport>
    </div>
  </div>
</template>

<script setup>
// import searchTab from './searchTab';
const emit = defineEmits(['search'])

const focus = ref(false)
const input = ref('')

const mounted = ref(false)

function onFoucs(value) {
  focus.value = value
}

function search() {
  emit('search', input.value)
}

onUnmounted(() => {
  document.getElementsByClassName('social_search_input')[0].removeEventListener('focus', onfocus)
  document.getElementsByClassName('social_search_input')[0].removeEventListener('blur', onfocus)
})

onMounted(() => {
  mounted.value = true
  document
    .getElementsByClassName('social_search_input')[0]
    .addEventListener('focus', onFoucs.bind(this, true))
  document
    .getElementsByClassName('social_search_input')[0]
    .addEventListener('blur', onFoucs.bind(this, false))
})
</script>

<style scoped lang="scss">
$--social-padding: 0 120px;
$--border-sizing: border-box !important;

.social_container_header_content {
  padding-top: 16px;
  padding-bottom: 22px;

  .social_container_header_title {
    font-size: 18px;
    font-weight: 700;
    line-height: 28px;
    letter-spacing: 0em;
    text-align: left;
    color: #fff;
  }
  .social_container_search_content {
    margin-top: 16px;
    background-color: #fff;
    width: 591px;
    height: 48px;
    border-radius: 4px;
    box-sizing: $--border-sizing;
    // display: flex;
    // align-items: center;

    .social_container_search {
      display: flex;
      align-items: center;
      padding: 0 4px 0 12px;
      input {
        border: 0;
        height: 22px;
        outline: 0;
        font-size: 14px;
        font-weight: 400;
        line-height: 22px;
        letter-spacing: 0em;
        text-align: left;
        // width: 527px;
        flex: 1;
        margin-right: 8px;
      }
      .ic_close {
        margin-right: 8px;
      }
      button {
        width: 40px;
        height: 40px;
        background: #3260c9;
        border: 0;
        border-radius: 4px;
        margin-top: 4px;
        margin-bottom: 4px;
        cursor: pointer;
      }
    }
    .social_container_hot {
      margin-top: 8px;
      //styleName: Body1
      font-size: 14px;
      font-weight: 700;
      line-height: 22px;
      letter-spacing: 0em;
      text-align: left;
      color: #fff;
      > :first-child {
        font-size: 14px;
        font-weight: 400;
        line-height: 22px;
        letter-spacing: 0em;
        text-align: left;
      }
    }
  }
}

.search_popover {
  position: absolute;
  // height: 0;
  overflow: hidden;
  top: 52px;
  left: 0;
  // height: 300px;
  background-color: #fff;
  right: 0;
  border-radius: 8px;
  box-sizing: inherit;
  box-shadow: 0px 11px 25px 0px #00000040;
  z-index: 2;
  // padding: 8px 0 15px 0;
  // transition: 1s ease;
  transition: max-height 0.3s linear;
  max-height: 0;

  > :first-child {
    // padding: 8px 0 15px 0;
    height: 100%;
    font-size: 12px;
    font-weight: 400;
    line-height: 22px;
    letter-spacing: 0em;
    text-align: left;
    padding: 8px 27px 0 16px;
    color: #727272;
    margin-bottom: 8px;
  }

  .search_popover_items {
    padding-bottom: 15px;
    .search_popover_item {
      &:hover {
        background-color: #2c7cf11a;
        > :last-child {
          opacity: 1;
        }
      }
      height: 100%;
      font-weight: 600;
      color: #3260c9;
      height: 36px;
      line-height: 36px;
      padding: 0 27px 0 16px;
      display: flex;
      align-items: center;
      width: 100%;

      > :first-child {
        width: 24px;
        margin-right: 10px;
      }

      > :last-child {
        opacity: 0;
        margin-left: auto;
        width: 12px;
      }
      // background-color:
    }
  }
}

.social_container_search {
  position: relative;
}
</style>
