<template>
  <div class="social_container_main">
    <div class="social_container_header">
      <search/>
    </div>
    <section class="social_container_section">
      <div class="social_container_bulletin">
        <div class="social_container_section_left">
          <div class="social_container_section_name">王大明，欢迎回来</div>
          <div class="social_container_section_deal">
            <div>
              <div>待签核</div>
              <div>1</div>
            </div>
            <div>
              <div>待签核</div>
              <div>1</div>
            </div>
            <div>
              <div>待签核</div>
              <div>1</div>
            </div>
            <div>
              <div>待签核</div>
              <div>1</div>
            </div>
          </div>
        </div>
        <div class="social_container_section_right">
          <div class="social_container_section_tabs">
            <div>系统通知</div>
            <div>服务公告</div>
          </div>
          <div class="social_container_section_bulletins">
            <div class="social_container_section_bulletin">
              <div class="text-ellipsis">
                您提交的O365帳號申請單（單號W234578696）已審核完成。帳密已發送到您申請的手機（0955123***）請在24小時內完成啟用。
              </div>
              <div>中央資訊資安團隊 2022/10/11</div>
            </div>
            <div class="social_container_section_bulletin">
              <div>
                您提交的O365帳號申請單（單號W234578696）被IT責任人退回。
              </div>
              <div>中央資訊資安團隊 2022/10/11</div>
            </div>
          </div>
        </div>
      </div>
      <div class="social_container_content">
        <div class="social_container_content_tabs">
          <div>热门申请</div>
          <div>服务公告</div>
          <div></div>
        </div>
        <div class="social_container_content_main">
          <div class="social_container_content_main_hot">
            <div>
              <img src="@/assets/images/social/Popular.png" />
              <div>全站最热门</div>
            </div>
            <div>行動辦公室(5)</div>
            <div>資安防禦(5)</div>
            <div>雲鋼運維(5)</div>
            <div>業務管理(5)</div>
            <div>開發管理(5)</div>
          </div>
          <div class="social_container_content_main_items">
            <div class="social_container_content_main_item">
              <div class="social_container_content_main_item_top">
                <img src="@/assets/images/social/supernotes.png" />
                <div>
                  <div>Super Notes郵箱申請</div>
                  <div>資安防禦</div>
                </div>
              </div>
              <div class="social_container_content_main_item_desc">
                集團員工個人郵箱使用申請集團員工個人郵箱使用申個
              </div>
            </div>
            <div class="social_container_content_main_item">
              <div class="social_container_content_main_item_top">
                <img src="@/assets/images/social/supernotes.png" />
                <div>
                  <div>Super Notes郵箱申請</div>
                  <div>資安防禦</div>
                </div>
              </div>
              <div class="social_container_content_main_item_desc">
                集團員工個人郵箱使用申請集團員工個人郵箱使用申個
              </div>
            </div>
            <div class="social_container_content_main_item">
              <div class="social_container_content_main_item_top">
                <img src="@/assets/images/social/supernotes.png" />
                <div>
                  <div>Super Notes郵箱申請</div>
                  <div>資安防禦</div>
                </div>
              </div>
              <div class="social_container_content_main_item_desc">
                集團員工個人郵箱使用申請集團員工個人郵箱使用申個
              </div>
            </div>
            <div class="social_container_content_main_item">
              <div class="social_container_content_main_item_top">
                <img src="@/assets/images/social/supernotes.png" />
                <div>
                  <div>Super Notes郵箱申請</div>
                  <div>資安防禦</div>
                </div>
              </div>
              <div class="social_container_content_main_item_desc">
                集團員工個人郵箱使用申請集團員工個人郵箱使用申個
              </div>
            </div>
            <div class="social_container_content_main_item">
              <div class="social_container_content_main_item_top">
                <img src="@/assets/images/social/supernotes.png" />
                <div>
                  <div>Super Notes郵箱申請</div>
                  <div>資安防禦</div>
                </div>
              </div>
              <div class="social_container_content_main_item_desc">
                集團員工個人郵箱使用申請集團員工個人郵箱使用申個
              </div>
            </div>
            <div class="social_container_content_main_item">
              <div class="social_container_content_main_item_top">
                <img src="@/assets/images/social/supernotes.png" />
                <div>
                  <div>Super Notes郵箱申請</div>
                  <div>資安防禦</div>
                </div>
              </div>
              <div class="social_container_content_main_item_desc">
                集團員工個人郵箱使用申請集團員工個人郵箱使用申個
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  </div>
</template>

<script setup>

import search from '../components/search.vue'
</script>

<style lang="scss" scoped>
@import '@/assets/styles/variables.module.scss';

$--social-padding: 0 120px;
$--border-sizing: border-box !important;

.social_container_main {
  padding:0 ;
  padding-bottom: 84px;
  padding-top:60px;
  // background-color: #e9e9e9;
  background: url('@/assets/images/social/bg.png');
  background-size: 100% 100%;
  .social_container_header {
    background: url('@/assets/images/social/work_banner.png');
    background-size: 100% 100%;
    width: 100%;
    height: 160px;
    padding: $--social-padding;
    box-sizing: $--border-sizing;
  }
  .social_container_header_content {
    padding-top: 16px;
    padding-bottom: 22px;
    .social_container_header_title {
      font-size: 18px;
      font-weight: 700;
      line-height: 28px;
      letter-spacing: 0em;
      text-align: left;
      color: #fff;
    }
    .social_container_search_content {
      margin-top: 16px;
      background-color: #fff;
      width: 591px;
      height: 48px;
      border-radius: 4px;
      box-sizing: $--border-sizing;
      // display: flex;
      // align-items: center;

      .social_container_search {
        display: flex;
        align-items: center;
        padding: 0 4px 0 12px;
        input {
          border: 0;
          height: 22px;
          outline: 0;
          font-size: 14px;
          font-weight: 400;
          line-height: 22px;
          letter-spacing: 0em;
          text-align: left;
          width: 527px;
          margin-right: 8px;
        }
        button {
          width: 40px;
          height: 40px;
          background: #3260c9;
          border: 0;
          border-radius: 4px;
          margin-top: 4px;
          margin-bottom: 4px;
          cursor: pointer;
        }
      }
      .social_container_hot {
        margin-top: 8px;
        //styleName: Body1
        font-size: 14px;
        font-weight: 700;
        line-height: 22px;
        letter-spacing: 0em;
        text-align: left;
        color: #fff;
        > :first-child {
          font-size: 14px;
          font-weight: 400;
          line-height: 22px;
          letter-spacing: 0em;
          text-align: left;
        }
      }
    }
  }
  .social_container_section {
    margin-top: 24px;
    padding: $--social-padding;
    .social_container_bulletin {
      display: flex;
      align-items: center;
      height: 193px;
      .social_container_section_left,
      .social_container_section_right {
        background-color: #fff;
        border-radius: 4px 4px 0px 0px;
        overflow: hidden;
      }
      .social_container_section_left {
        height: 100%;
        margin-right: 16px;
        width: 389px;
        .social_container_section_name {
          box-sizing: $--border-sizing;
          padding: 23.5px 0;
          padding-left: 24px;
          height: 75px;
          background-color: #3260c9;
          color: #fff;
          font-size: 18px;
          font-weight: 700;
          line-height: 28px;
          letter-spacing: 0em;
          text-align: left;
        }
        .social_container_section_deal {
          box-sizing: inherit;
          height: 118px;
          border: 1px solid #dcdcdc;
          border-top: 0;
          display: flex;
          > div {
            box-sizing: inherit;
            border: 1px solid #dcdcdc;
            flex: 1;
            text-align: center;
            padding-top: 22.5px;
            > :first-child {
              font-size: 14px;
              font-weight: 700;
              line-height: 22px;
              letter-spacing: 0em;
              text-align: center;
              color: #333333;
            }
            > :last-child {
              height: 48px;
              margin-top: 3px;
              font-size: 32px;
              font-weight: 700;
              line-height: 48px;
              letter-spacing: 0em;
              text-align: center;
              color: #437cff;
            }
          }
        }
      }
      .social_container_section_right {
        height: 100%;
        flex: 1;
        box-sizing: inherit;
        height: 100%;
        border: 1px solid #dcdcdc;

        .social_container_section_tabs {
          height: 48px;
          display: flex;
          align-items: center;
          padding-left: 16px;
          > div {
            font-size: 14px;
            font-weight: 400;
            line-height: 48px;
            letter-spacing: 0em;
            text-align: left;
            margin-right: 24px;
            height: 48px;
          }
          > :first-child {
            font-weight: 700;
            color: #3260c9;
            border-bottom: 2px solid #3260c9;
          }
        }
        .social_container_section_bulletins {
          border-top: 1px solid #dcdcdc;
          display: flex;
          flex-direction: column;
          height: 146px;
          padding: 0 16px;
          display: flex;
          flex-direction: column;
          > div {
            flex: 1;
          }
          > :first-child {
            border-bottom: 1px solid #e7e7e7;
          }
          .social_container_section_bulletin {
            flex: 1;
          

            > :first-child {
              font-size: 14px;
              font-weight: 600;
              letter-spacing: 0em;
              text-align: left;
              margin-bottom: 4px;
              padding:12px 0 4px 0;

            }
            > :last-child {
              font-size: 14px;
              font-weight: 400;
              letter-spacing: 0em;
              text-align: left;
              color: #727272;
              display:flex;
              align-items:center;
            }
          }
        }
      }
    }
    .social_container_content {
      padding-bottom: 66px;
      margin-top: 24px;
      background-color: #fff;
      border: 1px solid #dcdcdc;
      .social_container_content_tabs {
        height: 48px;
        display: flex;
        align-items: center;
        padding-left: 16px;
        border: 1px solid #dcdcdc;
        > div {
          font-size: 14px;
          font-weight: 400;
          line-height: 48px;
          letter-spacing: 0em;
          text-align: left;
          margin-right: 24px;
          height: 48px;
        }
        > :first-child {
          font-weight: 700;
          color: #3260c9;
          border-bottom: 2px solid #3260c9;
        }
      }
      .social_container_content_main {
        padding: 16px 16px 0 16px;
        .social_container_content_main_hot {
          width: fit-content;
          box-sizing: inherit;
          padding: 3px 4px;
          background-color: #f2f3f7;
          display: flex;
          align-items: center;
          > :first-child {
            background-color: #fff !important;
            padding: 5px 12px 5px 8px;
            display: flex;
            align-items: center;
            font-size: 14px;
            font-weight: 700;
            letter-spacing: 0em;
            text-align: left;
            color: #3260c9;
            img {
              width: 24px;
              height: 24px;
            }
          }
          > div {
            height: 34px;
            line-height: 34px;
            min-width: 91px;
            //styleName: Body1;
            font-size: 14px;
            font-weight: 400;
            // line-height: 22px;
            letter-spacing: 0em;
            text-align: left;
            margin-right: 12px;
            text-align: center;
          }
        }
        .social_container_content_main_items {
          margin-top: 16px;

          display: grid;
          grid-template-columns: 1fr 1fr 1fr;
          grid-template-rows: 118px 118px;
          grid-column-gap: 17px;
          grid-row-gap: 24px;
          > div:hover{
            background: linear-gradient(96.79deg, #d3e6ff 1.6%, #ffffff 90.87%);
            box-shadow: 0px 6px 15px 0px #0000001a;
          }

        
          > div {
            cursor:pointer;
            border-radius:4px;
            box-sizing: inherit;
            height: 118px;
            padding: 16px 14px 16px 16px;
            // border: 1px solid #dcdcdc;
            background: linear-gradient(186.12deg, #F1F7FF 1.79%, #F7FAFF 78.56%);

            img {
              height: 60px;
              // width: 48px;
              margin-right: 16px;
            }
          }
          .social_container_content_main_item_top {
            height: 48px;
            display: flex;
            > div {
              
              > :first-child {
                font-size: 14px;
                font-weight: 700;
                line-height: 22px;
                letter-spacing: 0em;
                text-align: left;
              }

              > :last-child {
                height: 22px;
                background-color: #fff;
                font-size: 12px;
                font-weight: 700;
                line-height: 18px;
                letter-spacing: 0em;
                text-align: left;
                width: 64px;
                padding: 2px 8px;
                border-radius: 4px;
                color: #3260c9;
                margin-top: 4px;
              }
            }
          }
          .social_container_content_main_item_desc {
            font-size: 14px;
            font-weight: 400;
            line-height: 22px;
            letter-spacing: 0em;
            text-align: left;
            color: #727272;
            margin-top: 16.89px;
          }
        }
      }
    }
  }
}
</style>
