<template>
  <div class="social_container_mains">
    <div class="social_container_header">
      <search />
    </div>
    <div class="social_container_content">
      <div class="social_container_content_search">
        <div class="social_container_search_title">
          <div>篩選條件</div>
          <div>重置</div>
        </div>
        <div>
          <el-checkbox-group v-model="checkList">
            <div>類別</div>
            <div>
              <el-checkbox label="行動辦公室" />
            </div>
          </el-checkbox-group>
        </div>
      </div>
      <div class="social_container_items"></div>
    </div>
  </div>
</template>

<script setup>
import search from '../components/search.vue'
</script>

<style lang="scss" scoped>
@import '@/assets/styles/variables.module.scss';

$--social-padding: 0 120px;
$--border-sizing: border-box !important;

.social_container_mains {
  box-sizing: $--border-sizing;
  background: red;
  padding: $--social-padding;
  padding-bottom: 84px;
  padding-top: 60px;
  .social_container_header_content {
    padding-top: 24px;
    // padding-bottom:0;
  }
  .social_container_header {
    // background: url('@/assets/images/social/work_banner.png');
    background-size: 100% 100%;
    width: 100%;
    // padding: $--social-padding;
    box-sizing: $--border-sizing;
  }

  .social_container_content {
    margin-top: 24px;
    // padding: $--social-padding;
    background: #fff;
    height: 300px;
    border: 1px solid #dcdcdc;
    border-radius: 8px;
    width: 100%;
    display: flex;
    .social_container_content_search {
      padding: 16px 24px 29px 16px;
      width: 180px;
      border-right: 1px solid #d9d9d9;
      height: 100%;
      .social_container_search_title {
        display: flex;
        align-items: center;
        > :first-child {
          font-size: 16px;
          font-weight: 700;
          line-height: 24px;
          letter-spacing: 0em;
          text-align: left;
          color: #333333;
        }

        > :last-child {
          margin-left: auto;
          font-size: 12px;
          font-weight: 700;
          line-height: 18px;
          letter-spacing: 0em;
          text-align: left;
          color: #3260c9;
        }
      }
    }
  }
}
</style>
