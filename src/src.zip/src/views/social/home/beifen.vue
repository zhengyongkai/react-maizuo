<template>
  <div class="homeMain">
    <!-- 轮播图 -->
    <el-carousel height="482px" arrow="never" indicator-position="none" :pause-on-hover="false">
      <el-carousel-item v-for="item in imgList" :key="item">
        <img :src="item" class="carousel_img" />
      </el-carousel-item>
    </el-carousel>
    <div class="socialHome_container_main homeContent">
      <!-- 服务提示 -->
      <div class="flex_strat_center">
        <div class="ball"></div>
        <div class="homeContent_title">{{$t('home.title1')}}</div>
      </div>
      <!-- 搜索登录框 -->
      <div class="flex_strat_center" style="margin-top:37px">
        <!-- 搜索框 -->
        <div class="homeContent_search"></div>

        <div class="homeContent_logged" v-if="userStore.isLogin">
          <div>
            <div>{{$t('home.welcome')}}{{userStore.realName}}</div>
            <div>
              {{$t('home.toWork')}}
              <span
                style="font-size:16px;font-weight: 700;line-height: 16px;"
              >→</span>
            </div>
          </div>
          <div>{{$t('home.formInfo')}}</div>
        </div>
        <!-- 登录二维码 -->
        <div class="homeContent_QR" v-else>
          <div id="QR"></div>
          <div class="homeContent_QR_info">
            <div
              style="font-size: 14px;font-weight: 600;line-height: 19px;letter-spacing: 0em;text-align: left;"
            >
              <div>{{$t('home.loginInfo1')}}</div>
              <div>{{$t('home.loginInfo2')}}</div>
            </div>
            <div
              @click="handleLogin"
              style="font-size: 12px;font-weight: 400;line-height: 16px;letter-spacing: 0em;display: flex;align-items: center;cursor: pointer;"
            >
              {{$t('home.loginInfo3')}}
              <span
                style="font-size:16px;font-weight: 700;line-height: 16px;"
              >→</span>
            </div>
          </div>
        </div>
      </div>
      <div class="homeContent_info">
        <div class="homeContent_info_item">
          <div class="homeContent_info_item1">
            <img src="@/assets/images/home/icon1.svg" alt />
            <div>{{$t('home.info_Item1_title')}}</div>
          </div>
          <div class="homeContent_info_item2">
            <div>{{$t('home.info_Item1_title')}}</div>
            <div>{{$t('home.info_Item1_content')}}</div>
          </div>
        </div>
        <div class="homeContent_info_item">
          <div class="homeContent_info_item1">
            <img src="@/assets/images/home/icon2.svg" alt />
            <div>{{$t('home.info_Item2_title')}}</div>
          </div>
          <div class="homeContent_info_item2">
            <div>{{$t('home.info_Item2_title')}}</div>
            <div>{{$t('home.info_Item2_content')}}</div>
          </div>
        </div>
        <div class="homeContent_info_item">
          <div class="homeContent_info_item1">
            <img src="@/assets/images/home/icon3.svg" alt />
            <div>{{$t('home.info_Item3_title')}}</div>
          </div>
          <div class="homeContent_info_item2">
            <div>{{$t('home.info_Item3_title')}}</div>
            <div>{{$t('home.info_Item3_content')}}</div>
          </div>
        </div>
        <div class="homeContent_info_item">
          <div class="homeContent_info_item1">
            <img src="@/assets/images/home/icon5.svg" alt />
            <div>{{$t('home.info_Item4_title')}}</div>
          </div>
          <div class="homeContent_info_item2">
            <div>{{$t('home.info_Item4_title')}}</div>
            <div>{{$t('home.info_Item4_content')}}</div>
          </div>
        </div>
      </div>
      <div
        style="width:100%;height:25px;font-size:18px;color:#3260C9;text-align:center;font-weight:700;margin-top:54px"
      >{{$t('home.info2_title')}}</div>
      <div class="homeContent_info2">
        <div>
          <span class="big_f">90</span>
          <span class="nomal_f">{{$t('home.info2_item1_unit')}}</span>
          <div class="small_f">{{$t('home.info2_item1_msg')}}</div>
        </div>
        <div>
          <span class="big_f">45</span>
          <span class="nomal_f">{{$t('home.info2_item2_unit')}}</span>
          <div class="small_f">{{$t('home.info2_item2_msg')}}</div>
        </div>
        <div>
          <span class="big_f">50</span>
          <span class="nomal_f">%</span>
          <div class="small_f">{{$t('home.info2_item3_msg')}}</div>
        </div>
        <div>
          <span class="big_f">400</span>
          <span class="nomal_f">{{$t('home.info2_item4_unit')}}</span>
          <div class="small_f">{{$t('home.info2_item4_msg')}}</div>
        </div>
      </div>
      <div class="homeContent_lebal" style="margin-top:61px">{{$t('home.content_lebal1')}}</div>

      <div class="homeContent_theme">
        <div v-for="(item,index) in themeList" :key="index" @click="toTheme(item)">
          <img :src="item.picture" />
          <div
            style="font-size: 16px;font-weight: 600;line-height: 22px;position:absolute;left: 24px;top: 57px;"
          >{{useLang(item,'name')}}</div>
        </div>
      </div>
      <div class="homeContent_lebal" style="margin-top:64px">服务公告</div>
      <div class="homeContent_notice">
        <div v-for="(item,index) in noticeList" :key="index">
          <div
            style="font-size: 16px;font-weight: 600;line-height: 24px;text-align: left;"
          >{{item.name}}</div>
          <div
            style="color:#727272;font-size: 14px;font-weight: 400;line-height: 22px;text-align: left;"
          >{{item.team}}{{item.time}}</div>
        </div>
      </div>
      <div class="flex_strat_center" style="margin-top:61px;display:flex;justify-content:center">
        <div class="ball"></div>
        <div style="color:#fff;margin-left:15px">
          <div
            style="height: 28px;font-size: 20px;font-weight: 700;line-height: 28px;"
          >{{$t('home.title2')}}</div>
          <div
            style="height:18px;font-size: 13px;font-weight: 600;line-height: 18px;letter-spacing: 0em;text-align: left;"
          >{{$t('home.title2_info')}}</div>
        </div>
      </div>
      <div class="homeContent_info3">
        <div>
          <div class="homeContent_info3_font1">1860042</div>
          <div class="homeContent_info3_font2">{{$t('home.info3_item1')}}</div>
        </div>
        <div>
          <div class="homeContent_info3_font1">5208</div>
          <div class="homeContent_info3_font2">{{$t('home.info3_item2')}}</div>
        </div>
        <div>
          <div class="homeContent_info3_font1">
            7
            <span>&times;</span>24
          </div>
          <div class="homeContent_info3_font2">{{$t('home.info3_item3')}}</div>
        </div>
      </div>
      <div class="homeContent_to">{{$t('home.enable')}}</div>
      <!-- <iframe
        id="myIframe"
        ref="myIframe"
        width="240"
        height="270"
        frameborder="0"
        scrolling="no"
        :src="src"
      ></iframe>-->
    </div>

    <div style="height:439px;background: #fff;"></div>
    <div style="height:290px;background: #F0F5FF;"></div>
    <div style="height: 530px;background:#333"></div>
  </div>
</template>

<script setup>
import axios from "axios";
import banner1 from "@/assets/images/home/banner1.png";
import banner2 from "@/assets/images/home/banner2.png";
import banner3 from "@/assets/images/home/banner3.png";
import { getLoginUrl } from "@/api/login";

import { selbasicConfigList } from "@/api/system/config";

import useUserStore from "@/store/modules/user";
import { useLang } from "@/utils/lang.js";

const userStore = useUserStore();

const { proxy } = getCurrentInstance();
const htmlContent = ref("");
const imgList = [banner1, banner2, banner3];

const route = useRoute();
// 主题列表
const themeList = ref([]);
//公告列表
const noticeList = ref([]);
function hideScanInfo() {
  nextTick(() => {
    var hsso_options = {
      scanPrompt: " ", //提示用戶掃碼，默認值為“請使用相信「掃一掃」功能”。
      imgSize: 109, // 二維碼圖片寬度，單位px，默認值為180。
      s0Prompt: " ", // 用戶已掃碼的提示，默認值為“請在相信手機端確認登錄操作”。
      s1Prompt: " ", //相信手機端操作已完成時的提示，默認值為“中央資訊授權中心正在登錄”
      imgMarginTop: "0px", // 二維碼圖片寬度，單位px，默認值為180。
      imgMarginBottom: "0px", //二維碼圖片下端空白高度，單位px，默認值為30。
      refershPrompt: " ", // 二維碼圖片寬度，單位px，默認值為180。
      useDefaultCsss: false //是否加載默認CSS樣式，默認值為true。
    };
    var hsso = new BelieveSSO("#QR", hsso_options);
    var qrcode = document.getElementsByClassName("qrcode");
    // qrcode[0].style.margin = "5px 0 0 5px";
    console.log("qrcode", qrcode);

    // const QR = proxy.$("#QR");
    // QR.append(hsso);
    // console.log("hsso", hsso);

    // const QR = document.getElementById("QR");
    // // hssoDiv.textContent = "hsso";
    // QR.appendChild(hsso);
  });
  getList();
}
hideScanInfo();

function handleLogin() {
  getLoginUrl().then(res => {
    if (res) {
      window.open(res.msg, "_self");
    }
  });
}
function getList() {
  selbasicConfigList({ type: 1, pageSize: 3 }).then(res => {
    themeList.value = res.rows;
  });

  noticeList.value = [
    {
      name: "管理各式表单，可下载依公司实际需求修改使用！",
      name_zh_tw: "管理各式表單，可下載依公司實際需求修改使用！",
      name_en_us: "XXXXXXXXXXX",
      team: "中央资讯资安团队",
      time: "2023/10/11"
    },
    {
      name:
        "新服务类型的表单上线！虎耀云服务申请，让您的业务畅行在集团各厂区，立即申请试用！",
      name_zh_tw:
        "新服務類型的表單上線！虎躍雲服務申請，讓您的業務暢行在集團各廠區，立即申請試用！",
      name_en_us: "XXXXXXXXXXX",
      team: "中央资讯",
      time: "2023/10/11"
    },
    {
      name:
        "满意度反馈，有礼真好！只要填写回答，就可以获得精美小礼。别怀疑！幸运儿就是你~",
      name_zh_tw:
        "滿意度反饋，有禮真好！ 只要填答問卷，就可以獲得精美小禮。別懷疑！幸運兒就是你～",
      name_en_us: "XXXXXXXXXXX",
      team: "中央资讯",
      time: "2023/10/11"
    }
  ];
}

// onBeforeUnmount(() => {
//   const oScript = document.createElement("script");
//   const oScript1 = document.createElement("script");

//   oScript.type = "text/javascript";
//   oScript.src = "https://sso.foxconn.com/lib/jquery/dist/jquery.min.js";
//   oScript1.src =
//     "https://sso.foxconn.com/Civet/JsLogin?client_id=misId&redirect_uri=https://mis.efoxconn.com/social/home&scope=openid profile foxconn&state=";
//   document.body.appendChild(oScript);
//   document.body.appendChild(oScript1);
// });
</script>

<style lang='scss' scoped>
.sso-qrcode .qrcode {
  margin: 0 !important;
}
.homeMain {
  width: 100%;
}
.homeContent {
  position: absolute;
  width: 100%;
  top: 142px;
  left: 0;
}
.homeContent_title {
  font-size: 23px;
  font-weight: 600;
  line-height: 31px;
  letter-spacing: 0em;
  text-align: left;
  color: #ffffff;
  margin-left: 20px;
}

.homeContent_search {
  width: 560px;
  height: 130px;
  border-radius: 8px;
  background: #ffffff;
}
.homeContent_QR {
  width: 293px;
  height: 130px;
  border-radius: 8px;
  background: #0000009e;
  margin-left: 13px;
  padding: 10px;
  position: relative;
  .homeContent_QR_info {
    position: absolute;
    width: 153px;
    height: 101px;
    top: 10px;
    right: 0;
    color: #fff;
    display: flex;
    flex-direction: column;
    justify-content: space-between;
  }
}
.homeContent_logged {
  width: 293px;
  height: 130px;
  border-radius: 8px;
  background: #3260c9;
  color: #fff;
  display: flex;
  flex-direction: column;
  justify-content: space-between;
  margin-left: 13px;
  padding: 18px 24px;

  > :first-child {
    display: flex;
    justify-content: space-between;
    font-size: 14px;
    font-weight: 700;
    line-height: 28px;
    letter-spacing: 0em;
    text-align: left;
  }
  > :last-child {
    font-size: 14px;
    font-weight: 700;
    line-height: 21px;
    letter-spacing: 0em;
    text-align: left;
    color: #b3c8fa;
    border-left: 4px solid #2c7cf1;
    padding-left: 10px;
  }
}
.homeContent_info {
  width: 100%;
  height: 115px;
  border-radius: 8px;
  background: #14cab4;
  margin-top: 27px;
  box-shadow: 0px 24px 52px 0px #0000001a;

  display: flex;
  justify-content: space-around;
  color: #fff;
  text-align: center;
  overflow: hidden;
  .homeContent_info_item {
    width: 25%;
    transition: all 0.3s ease;
    cursor: pointer;
  }

  .homeContent_info_item:hover {
    transform: translateY(-115px);
  }
  .homeContent_info_item1 {
    height: 100%;
    display: flex;
    flex-direction: column;
    justify-content: center;
    align-items: center;
    font-size: 16px;
    font-weight: 600;
    letter-spacing: 0em;
    > img {
      margin-bottom: 16px;
      width: 27px;
      height: 27px;
    }
  }
  .homeContent_info_item2 {
    height: 100%;
    display: flex;
    flex-direction: column;
    justify-content: center;
    align-items: center;
    font-size: 14px;
    font-weight: 600;
    letter-spacing: 0em;
    border-bottom: 4px solid #fff;
    :first-child {
      font-size: 16px;
      margin-bottom: 13px;
    }
  }
}
.homeContent_info2 {
  margin-top: 37px;
  color: #3260c9;
  display: flex;
  justify-content: space-around;
  text-align: center;
}

.homeContent_lebal {
  font-size: 18px;
  font-weight: 700;
  line-height: 25px;
  letter-spacing: 0em;
  text-align: left;
  padding-left: 11px;
  border-left: 4px solid #333333;
}
.homeContent_theme {
  padding-top: 20px;
  height: 112px;
  width: 100%;
  display: flex;
  justify-content: space-around;
  > * {
    cursor: pointer;
    position: relative;
  }
  img {
    width: 281px;
    height: 107px;
  }
}
.homeContent_notice {
  height: 255px;
  border-radius: 8px;
  box-shadow: 0px 0px 0px 0px #0000001a;
  background: #ffffff;
  margin-top: 25px;
  box-shadow: 0px 24px 52px 0px #0000001a;
  box-shadow: 0px 95px 95px 0px #00000017;
  box-shadow: 0px 214px 129px 0px #0000000d;
  box-shadow: 0px 381px 152px 0px #00000003;
  box-shadow: 0px 595px 167px 0px #00000000;
  padding: 10px 28px;
  > * {
    height: 74px;
    border-bottom: 1px solid #e7e7e7;
    display: flex;
    flex-direction: column;
    justify-content: center;
    cursor: pointer;
  }
}
.homeContent_info3 {
  display: flex;
  margin-top: 52px;
  justify-content: space-around;
  color: #fff;
  text-align: center;

  .homeContent_info3_font1 {
    font-size: 36px;
    font-weight: 600;
    line-height: 22px;
    letter-spacing: 0em;
    text-align: center;
  }
  .homeContent_info3_font2 {
    line-height: 22px;
    margin-top: 12px;
  }
}

.homeContent_to {
  width: 340px;
  height: 48px;
  margin: 37px auto 0;

  border-radius: 12px;
  background: linear-gradient(91.84deg, #3260c9 16.67%, #14cab4 109.72%);

  font-size: 16px;
  font-weight: 600;
  line-height: 48px;
  letter-spacing: 0em;
  text-align: center;
  color: #fff;
}
// 轮播图图片
.carousel_img {
  height: 100%;
  width: 100%;
  overflow-clip-margin: content-box;
  overflow: clip;
  object-fit: cover;
}

.ball {
  width: 47px;
  height: 47px;
  border-radius: 50%;
  background: #3260c9;
}

.flex_strat_center {
  display: flex;
  justify-content: flex-start;
  align-items: center;
}

.big_f {
  font-size: 40px;
  font-weight: 600;
  line-height: 22px;

  text-align: center;
}

.nomal_f {
  font-size: 16px;
  font-weight: 600;
  line-height: 22px;

  text-align: center;
  color: #3260c9;
}
.small_f {
  margin-top: 15px;
  font-size: 14px;
  font-weight: 600;
  line-height: 22px;

  text-align: center;
  color: #90afdc;
}
</style>
