<template>
  <div class="homeMain">
    <!-- 轮播图 -->
    <el-carousel
      height="600px"
      width="100%"
      arrow="never"
      indicator-position="none"
      :pause-on-hover="false"
    >
      <el-carousel-item v-for="item in imgList" :key="item">
        <img :src="item.img" class="carousel_img" />
        <div style="position:absolute;left:360px;top:187px;color:#fff">
          <div style="font-size: 60px;font-weight: 700;line-height: 82px;">{{useLang(item,'title')}}</div>
          <div style="font-size: 24px;font-weight: 400;line-height: 35px;">{{useLang(item,'info')}}</div>
        </div>
      </el-carousel-item>
    </el-carousel>
    <div class="flex_center">
      <div class="search"></div>
      <div class="QRcode_logged QRcode" v-if="userStore.isLogin">
        <div>
          <div>{{userStore.realName}},{{$t('home.welcome')}}</div>
          <div>{{$t('home.formInfo')}}</div>
        </div>

        <div
          style="font-size: 16px;font-weight: 700;line-height: 24px;color: #3260C9;cursor: pointer;"
          @click="toGongzuotai()"
        >
          {{$t('home.toWork')}}
          <img src="@/assets/images/home/right.png" />
        </div>
      </div>
      <!-- 登录二维码 -->
      <div class="QRcode_QR QRcode" v-else>
        <div id="QR"></div>
        <div class="QR_info">
          <div>
            <div
              style="font-size: 18px;font-weight: 700;line-height: 32px;letter-spacing: 1px;"
            >{{$t('home.loginInfo1')}}</div>
            <div style="font-size:22px;line-height:28px;font-weight: 700">{{$t('home.loginInfo2')}}</div>
          </div>
          <div
            @click="handleLogin"
            style="font-size: 16px;font-weight: 700;line-height: 24px;letter-spacing: 0em;display: flex;align-items: center;cursor: pointer;color: #3260C9;"
          >
            {{$t('home.loginInfo3')}}
            <img src="@/assets/images/home/right.png" />
          </div>
        </div>
      </div>
    </div>
    <div class="dataShow">
      <div class="home_h1">融合業務 技術驅動</div>
      <div class="home_h2">IT與業務深度融合，技術驅動並引領業務改革，滲透到業務橫向與管理縱向領域的全價值鏈數字化</div>
      <div class="dataShow_data socialHome_container_main">
        <div class="dataShow_data_item">
          <div>
            90
            <span>秒</span>
          </div>
          <div>每單平均錄單速度</div>
        </div>
        <div class="dataShow_data_item">
          <div>
            45
            <span>秒</span>
          </div>
          <div>最快接單速度</div>
        </div>
        <div class="dataShow_data_item">
          <div>
            50
            <span>%</span>
          </div>
          <div>降低人工審批成本</div>
        </div>
        <div class="dataShow_data_item">
          <div>
            400
            <span>單</span>
          </div>
          <div>單日在線可視化跟蹤</div>
        </div>
      </div>

      <div class="formInfo socialHome_container_main">
        <div class="home_h1">整合平台優勢 為效率而生</div>
        <div class="home_h2">內部數據互通，鏈接各單位，高效輸出最佳決策</div>
        <div class="formInfo_more">
          查看更多
          <img src="@/assets/images/home/right.png" />
        </div>
        <div class="formInfo_Edition">
          <div
            v-for="(item,index) in themeList"
            :key="index"
            @mousemove.capture="active = item.name"
            class="formInfo_Editon_item"
            :class="active == item.name?'formInfo_Editon_item_active':''"
          >
            <div class="formInfo_Editon_item_mode1">
              <div>
                <div style="font-size: 32px;line-height: 48px;">{{item.name}}</div>
                <div style="font-size: 18px;line-height: 28px;">{{item.description}}</div>
              </div>
              <div style="font-size:16px;margin-top:14px;padding:5px 10px;line-height:36px">
                <li v-for="(it,i) in item.forms" :key="i">
                  <span v-if="i <= 4">{{it.formName}}</span>
                </li>
                <!-- <li v-for="(it,i) in item.formIds" :key="i">{{i}}</li>
                <li>ddddd</li>-->
              </div>
              <div style="cursor: pointer;margin-top:14px">
                <img src="@/assets/images/home/right_light.png" />
              </div>
            </div>
            <div class="formInfo_Editon_item_mode2">
              <div style="font-size: 36px;font-weight: 700;line-height: 49px;">{{item.name}}</div>
              <div style="width:33px;height:2px;background:#fff;margin:12px 0"></div>
              <div style="font-size: 18px;font-weight: 600;line-height: 25px;">{{item.description}}</div>
            </div>
            <div class="formInfo_Editon_img1">
              <img v-if="index == 0" src="@/assets/images/home/img1.png" alt class="img1" />
              <img v-else-if="index == 1" src="@/assets/images/home/img2.png" class="img2" alt />
              <img v-else-if="index == 2" src="@/assets/images/home/img3.png" alt class="img3" />
            </div>
            <div class="formInfo_Editon_img2">
              <img v-if="index == 0" src="@/assets/images/home/img4.png" alt />
              <img v-else-if="index == 1" src="@/assets/images/home/img5.png" alt />
              <img v-else-if="index == 2" src="@/assets/images/home/img6.png" alt />
            </div>
          </div>
        </div>
      </div>
    </div>
    <div class="noticeRoll">
      <div
        class="socialHome_container_main noticeRoll_content1"
        ref="noticeRollRef"
        id="noticeRollRef"
      >
        <div style="font-size: 36px;line-height: 28px;">資訊服務申請平台（ITSM）</div>
        <div style="font-size: 18px;line-height: 28px;margin-top:16px">從整套方案到單個模塊。隨需而動</div>
        <div class="noticeRoll_data" v-if="noticeRollShow">
          <div>
            <div>
              <!-- <selfNumberGrow
                :startVal="0"
                :endVal="860042"
                :duration="3600"
                customStyle="font-size: 48px;"
              ></selfNumberGrow>-->
              <!-- <countTo :startVal="0" :endVal="860042" :duration="3000"></countTo> -->
              <count-up
                :end-val="860042"
                :duration="2.5"
                :scrollSpyOnce="true"
                :enableScrollSpy="true"
                :scrollSpyDelay="50"
              ></count-up>
            </div>
            <div>累計申請表單量</div>
          </div>
          <div>
            <div>7&times;24</div>
            <div>全天候無間斷服務支持</div>
          </div>
          <div>
            <div>
              <count-up
                :end-val="345208"
                :duration="2.5"
                :scrollSpyOnce="true"
                :enableScrollSpy="true"
                :scrollSpyDelay="50"
              ></count-up>
            </div>
            <div>累計到訪人數</div>
          </div>
        </div>
      </div>
      <div class="socialHome_container_main noticeRoll_content2">
        <div></div>
      </div>
    </div>
  </div>
</template>

<script setup>
import CountUp from "vue-countup-v3";
// import type { ICountUp, CountUpOptions } from "vue-countup-v3";
import axios from "axios";
import banner1 from "@/assets/images/home/banner1.png";
import banner2 from "@/assets/images/home/banner2.png";
import banner3 from "@/assets/images/home/banner3.png";
import banner4 from "@/assets/images/home/banner4.png";

import { getLoginUrl } from "@/api/login";

import { selbasicConfigList } from "@/api/system/config";

import useUserStore from "@/store/modules/user";
import { useLang } from "@/utils/lang.js";

// import "intersection-observer";

const userStore = useUserStore();

const { proxy } = getCurrentInstance();
const htmlContent = ref("");
const imgList = [
  {
    img: banner1,
    title: "资讯一键同步",
    title_en_us: "",
    title_zh_tw: "資訊一鍵同步",
    info: "同步多个渠道的信息，实现个人信息管理",
    info_en_us: "",
    info_zh_tw: "同步多個渠道的信息，實現個人信息管理"
  },
  {
    img: banner2,
    title: "进度实时追踪",
    title_en_us: "",
    title_zh_tw: "進度實時追蹤",
    info: "实时追踪任务进度，即时了解工作进展",
    info_en_us: "",
    info_zh_tw: "實時追蹤任務進度，即時瞭解工作進展"
  },
  {
    img: banner3,
    title: "数据安全防护",
    title_en_us: "",
    title_zh_tw: "數據安全防護",
    info: "数据安全防护，确保信息安全与隐私保护",
    info_en_us: "",
    info_zh_tw: "數據安全防護，確保信息安全與隱私保護"
  },
  {
    img: banner4,
    title: "办公无纸又环保",
    title_en_us: "",
    title_zh_tw: "辦公無紙又環保",
    info: "全程数位化，不仅方便快捷，更贡献环保",
    info_en_us: "",
    info_zh_tw: "全程數位化，不僅方便快捷，更貢獻環保"
  }
];

const route = useRoute();
// 主题列表
const themeList = ref([]);
const active = ref("");
//公告列表
const noticeList = ref([]);
const noticeRollShow = ref(false);
function hideScanInfo() {
  nextTick(() => {
    var hsso_options = {
      scanPrompt: " ", //提示用戶掃碼，默認值為“請使用相信「掃一掃」功能”。
      imgSize: 126, // 二維碼圖片寬度，單位px，默認值為180。
      s0Prompt: " ", // 用戶已掃碼的提示，默認值為“請在相信手機端確認登錄操作”。
      s1Prompt: " ", //相信手機端操作已完成時的提示，默認值為“中央資訊授權中心正在登錄”
      imgMarginTop: "0px", // 二維碼圖片寬度，單位px，默認值為180。
      imgMarginBottom: "0px", //二維碼圖片下端空白高度，單位px，默認值為30。
      refershPrompt: " ", // 二維碼圖片寬度，單位px，默認值為180。
      useDefaultCsss: false //是否加載默認CSS樣式，默認值為true。
    };
    var hsso = new BelieveSSO("#QR", hsso_options);
    var qrcode = document.getElementsByClassName("qrcode");
    // qrcode[0].style.margin = "5px 0 0 5px";
    // console.log("qrcode", qrcode);

    // const QR = proxy.$("#QR");
    // QR.append(hsso);
    // console.log("hsso", hsso);

    // const QR = document.getElementById("QR");
    // // hssoDiv.textContent = "hsso";
    // QR.appendChild(hsso);
  });
  getList();
}

hideScanInfo();

function handleLogin() {
  getLoginUrl().then(res => {
    if (res) {
      window.open(res.msg, "_self");
    }
  });
}
function getList() {
  selbasicConfigList({ type: 1, pageSize: 3 }).then(res => {
    themeList.value = res.rows;
    active.value = res.rows[0].name;
  });

  noticeList.value = [
    {
      name: "管理各式表单，可下载依公司实际需求修改使用！",
      name_zh_tw: "管理各式表單，可下載依公司實際需求修改使用！",
      name_en_us: "XXXXXXXXXXX",
      team: "中央资讯资安团队",
      time: "2023/10/11"
    },
    {
      name:
        "新服务类型的表单上线！虎耀云服务申请，让您的业务畅行在集团各厂区，立即申请试用！",
      name_zh_tw:
        "新服務類型的表單上線！虎躍雲服務申請，讓您的業務暢行在集團各廠區，立即申請試用！",
      name_en_us: "XXXXXXXXXXX",
      team: "中央资讯",
      time: "2023/10/11"
    },
    {
      name:
        "满意度反馈，有礼真好！只要填写回答，就可以获得精美小礼。别怀疑！幸运儿就是你~",
      name_zh_tw:
        "滿意度反饋，有禮真好！ 只要填答問卷，就可以獲得精美小禮。別懷疑！幸運兒就是你～",
      name_en_us: "XXXXXXXXXXX",
      team: "中央资讯",
      time: "2023/10/11"
    }
  ];
}

// noticeRollRef;
// const noticeRollRef = ref(null);
// nextTick(() => {
//   console.log("1112222", proxy.$refs["noticeRollRef"]);
// });
// const options = {
//   root: null,
//   rootMargin: "0px",
//   threshold: 0.5 // 0.5表示元素50%进入可视区域时触发
// };
// const observer = new IntersectionObserver(entries => {
//   console.log("1112222222222");
//   entries.forEach(entry => {
//     if (entry.isIntersecting) {
//       // 元素进入可视区域，执行数字滚动动画
//     }
//   });
// }, options);
nextTick(() => {
  window.addEventListener("scroll", function() {
    // const windowHeight = window.innerHeight;
    // const windowWidth = window.innerWidth;
    const noticeRollRef = document.getElementById("noticeRollRef");
    const noticeRoll = noticeRollRef.getBoundingClientRect();
    if (noticeRoll.top < 1093) {
      noticeRollShow.value = true;
    } else {
      noticeRollShow.value = false;
    }
    // console.log("clientRect", windowHeight, windowWidth, clientRect);
  });
});
</script>

<style lang='scss' scoped>
.sso-qrcode .qrcode {
  margin: 0 !important;
}
.homeMain {
  width: 100%;
}

// 轮播图图片
.carousel_img {
  height: 100%;
  width: 100%;
  overflow-clip-margin: content-box;
  overflow: clip;
  object-fit: cover;
}
.flex_center {
  position: absolute;
  top: 515px;
  left: 0;
  display: flex;
  justify-content: center;
  align-items: center;
  width: 100%;
}
.search {
  width: 795px;
  height: 158px;
  // top: 515px;
  // left: 360px;
  padding: 16px 24px 16px 24px;
  border-radius: 8px;
  border: 1px;
  gap: 16px;
  background: #fff;
  margin-right: 16px;
}

.QRcode {
  width: 389px;
  height: 158px;

  padding: 16px 24px 16px 24px;
  border-radius: 8px;
  border: 1px;
  // gap: 24px;
  background: linear-gradient(
    86.58deg,
    rgba(255, 255, 255, 0.7) 40.94%,
    rgba(230, 250, 255, 0.658) 73.43%,
    rgba(255, 255, 255, 0.7) 101.14%
  );
  -webkit-backdrop-filter: blur(10px);
  backdrop-filter: blur(20px);

  box-shadow: 0px 4px 20px 0px #98989840;

  border-image-source: linear-gradient(180deg, #d7f5ff 0%, #d3e1eb 100%);
}
.QRcode_logged {
  //styleName: H3;

  font-size: 18px;
  font-weight: 700;
  line-height: 28px;
  letter-spacing: 0em;
  text-align: left;
  display: flex;
  flex-direction: column;
  justify-content: space-between;
}
.QRcode_QR {
  position: relative;

  .QR_info {
    position: absolute;
    width: 153px;
    height: 120px;
    top: 16px;
    left: 172px;
    color: #000;
    display: flex;
    flex-direction: column;
    justify-content: space-between;
  }
}
.home_h1 {
  font-size: 36px;
  font-weight: 600;
  line-height: 49px;
  letter-spacing: 0em;

  background: linear-gradient(to right, #333333 0%, #3260c9 100%);
  -webkit-background-clip: text;
  -webkit-text-fill-color: transparent;
}
.home_h2 {
  margin-top: 8px;
  font-size: 16px;
  font-weight: 600;
  line-height: 22px;
  letter-spacing: 0em;
  color: #727272;
}
.dataShow {
  margin-top: 153px;
  text-align: center;

  .dataShow_data {
    margin-top: 24px;
    display: flex;
    justify-content: space-around;
  }
  .dataShow_data_item {
    font-size: 60px;
    font-weight: 700;
    color: #3260c9;
    :first-child {
      span {
        font-size: 20px;
        font-weight: 600;
        color: #3260c9;
      }
    }
    :last-child {
      font-size: 16px;
      font-weight: 600;
      line-height: 22px;
      letter-spacing: 0em;
      color: #727272;
    }
  }
}

.formInfo {
  margin-top: 184px;
  .formInfo_more {
    margin: 8px 0;
    font-size: 14px;
    font-weight: 700;
    line-height: 22px;
    letter-spacing: 0em;
    text-align: right;
    color: #3260c9;
    cursor: pointer;
  }
}

.formInfo_Edition {
  height: 385px;
  display: flex;
  justify-content: space-between;
  transition: width 0.3s ease;
  -webkit-transition: width 0.3s ease;
  -moz-transition: width 0.3s ease;

  .formInfo_Editon_item_active {
    height: 385px;
    width: 592px !important;
    // transition: width 0.3s ease;

    background-image: url("../../../../src/assets/images/home/editionBg.png") !important;
    background-repeat: no-repeat;
    background-size: 100%;
    .formInfo_Editon_item_mode1 {
      opacity: 1;

      transform: translateX(0px);
      // transition: width 0.3s ease;
    }
    .formInfo_Editon_item_mode2 {
      transform: translateX(-30px);

      // transform: translateX(288px);
      opacity: 0;
    }
    .formInfo_Editon_img1 {
      .img1 {
        opacity: 0.3;
        top: -120px;
        // right: -20px;
      }
      .img2 {
        opacity: 0;
        top: -120px;
      }
      .img3 {
        opacity: 0;
        top: -120px;
      }
      // transform: translate(80px, -80px);
    }
    .formInfo_Editon_img2 {
      opacity: 1;
      // bottom: 24px;
      // right: 24px;
      // transform: translate(0);
      bottom: 24px;
      // right: 24px;
    }
  }
  .formInfo_Editon_item {
    width: 288px;
    height: 100%;
    border-radius: 10px;
    text-align: left;

    color: #fff;
    font-weight: 600;
    position: relative;
    background: linear-gradient(136.7deg, #40a5fb 4.83%, #1867ff 98.97%),
      linear-gradient(0deg, #f1f5fe, #f1f5fe);
    transition: width 0.3s ease;
    -webkit-transition: width 0.3s ease;
    -moz-transition: width 0.3s ease;

    overflow: hidden;
    cursor: pointer;
  }
  .formInfo_Editon_item_mode1 {
    width: 288px;
    height: 325px;
    transform: translateX(-80px);
    transition: transform 0.3s ease;
    -webkit-transition: transform 0.3s ease;
    -moz-transition: transform 0.3s ease;
    display: flex;
    flex-direction: column;
    justify-content: space-between;
    opacity: 0;
    position: absolute;
    top: 36px;
    left: 30px;
    padding: 0 30px;
    z-index: 1;
  }
  .formInfo_Editon_item_mode2 {
    width: 240px;
    // height: 100%;
    // margin-top: 200px;
    position: absolute;
    bottom: 40px;
    left: 24px;
    z-index: 0;
    transform: translate(0px, 0px);
    -webkit-transition: transform 0.3s ease;
    -moz-transition: transform 0.3s ease;
    transition: transform 0.3s ease;

    // padding: 0 30px;
  }

  .formInfo_Editon_img1 {
    // transform: translateX(0px);
    // transition: transform 0.3s ease;

    // position: absolute;
    // top: 0;
    // right: 0;
    z-index: 9;
    > img {
      height: 113px;
    }
    .img1 {
      -webkit-transition: top 0.6s ease, opacity 0.2s ease;
      -moz-transition: top 0.6s ease, opacity 0.2s ease;
      transition: top 0.6s ease, opacity 0.2s ease;
      position: absolute;
      top: 44px;
      left: 113px;
    }
    .img2 {
      -webkit-transition: top 0.6s ease, opacity 0.2s ease;
      -moz-transition: top 0.6s ease, opacity 0.2s ease;
      transition: top 0.6s ease, opacity 0.2s ease;
      position: absolute;
      top: 44px;
      right: 24px;
    }

    .img3 {
      -webkit-transition: top 0.6s ease, opacity 0.2s ease;
      -moz-transition: top 0.6s ease, opacity 0.2s ease;
      transition: top 0.6s ease, opacity 0.2s ease;
      position: absolute;
      top: 44px;
      right: 24px;
    }
  }
  .formInfo_Editon_img2 {
    position: absolute;
    // bottom: -40px;
    // right: -40px;
    bottom: -14px;
    right: 24px;
    opacity: 0;
    z-index: 9;
    // transform: translateY(80px);
    opacity: 0;
    // transition: transform 0.3s ease-in-out;
    -webkit-transition: bottom 1s ease, opacity 1.3s ease;
    -moz-transition: bottom 1s ease, opacity 1.3s ease;
    transition: bottom 1s ease, opacity 1.3s ease;

    > img {
      height: 217px;
    }
  }
}

.noticeRoll {
  width: 100%;
  height: 670px;
  margin-top: 90px;
  background-image: url("../../../../src/assets/images/home/noticeRoll_bg.png") !important;
  background-repeat: no-repeat;
  background-size: cover;
  color: #fff;
  overflow: auto;
  position: relative;
  font-weight: 700;

  .noticeRoll_content1 {
    height: 670px;
    display: flex;
    flex-direction: column;
    justify-content: center;
  }
  .noticeRoll_content2 {
    height: 550px;
    background-image: url("../../../../src/assets/images/home/noticeRoll_bg2.png") !important;
    background-repeat: no-repeat;
    background-size: cover;
    // position: sticky;
    bottom: 0;
    left: 0;
  }
  .noticeRoll_data {
    margin-top: 36px;
    display: flex;
    justify-content: flex-start;
    text-align: left;
    > * {
      margin-right: 80px;

      > :first-child {
        font-size: 48px;
        font-weight: 700;
        line-height: 65px;
      }
      > :last-child {
        font-size: 18px;
        font-weight: 600;
        line-height: 25px;
      }
    }
  }
}
</style>
