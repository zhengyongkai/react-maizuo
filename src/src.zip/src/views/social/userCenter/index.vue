<template>
  <div class="social_container social_container_main">
    <el-form ref="formRef" :model="form" :rules="rules" label-width="130px">
      <el-tabs v-model="active">
        <el-tab-pane :label="$t('userCenter.tab1')" :name="$t('userCenter.tab1')">
          <template #label>
            <div class="custom-tabs-label">
              <!-- <svg-icon icon-class="tab1" /> -->
              <span>{{$t('userCenter.tab1')}}</span>
            </div>
          </template>
          <el-row>
            <el-col :span="8">
              <el-form-item :label="$t('userCenter.userName')" prop="formName">
                <el-input v-model="form.userName" placeholder disabled="disabled" />
              </el-form-item>
            </el-col>
            <el-col :span="8">
              <el-form-item :label="$t('userCenter.realName')" prop="formName">
                <el-input v-model="form.realName" placeholder disabled="disabled" />
              </el-form-item>
            </el-col>
            <el-col :span="8">
              <el-form-item :label="$t('userCenter.sex')" prop="formName">
                <el-input v-model="form.sexStr" placeholder disabled="disabled" />
              </el-form-item>
            </el-col>
          </el-row>
          <el-row>
            <el-col :span="8">
              <el-form-item :label="$t('userCenter.phoneNumber')" prop="formName">
                <el-input v-model="form.phoneNumber" placeholder disabled="disabled" />
              </el-form-item>
            </el-col>
            <el-col :span="8">
              <el-form-item :label="$t('userCenter.birthdate')" prop="formName">
                <el-input v-model="form.birthdate" placeholder disabled="disabled" />
              </el-form-item>
            </el-col>
            <el-col :span="8">
              <el-form-item :label="$t('userCenter.eduDegree')" prop="formName">
                <el-input v-model="form.eduDegree" placeholder disabled="disabled" />
              </el-form-item>
            </el-col>
          </el-row>
        </el-tab-pane>
      </el-tabs>
      <el-tabs v-model="active1">
        <el-tab-pane :label="$t('userCenter.tab2')" :name="$t('userCenter.tab2')">
          <template #label>
            <div class="custom-tabs-label">
              <!-- <svg-icon icon-class="tab1" /> -->
              <span>{{$t('userCenter.tab2')}}</span>
            </div>
          </template>
          <el-row>
            <el-col :span="8">
              <el-form-item :label="$t('userCenter.hireDate')" prop="formName">
                <el-input v-model="form.hireDate" placeholder disabled="disabled" />
              </el-form-item>
            </el-col>
            <el-col :span="8">
              <el-form-item :label="$t('userCenter.company')" prop="formName">
                <el-input v-model="form.company" placeholder disabled="disabled" />
              </el-form-item>
            </el-col>
            <el-col :span="8">
              <el-form-item :label="$t('userCenter.email')" prop="formName">
                <el-input v-model="form.email" placeholder disabled="disabled" />
              </el-form-item>
            </el-col>
          </el-row>
          <el-row>
            <el-col :span="8">
              <el-form-item :label="$t('userCenter.subOrg')" prop="formName">
                <el-input v-model="form.subOrg" placeholder disabled="disabled" />
              </el-form-item>
            </el-col>
            <el-col :span="8">
              <el-form-item :label="$t('userCenter.bg')" prop="formName">
                <el-input v-model="form.bg" placeholder disabled="disabled" />
              </el-form-item>
            </el-col>
            <el-col :span="8">
              <el-form-item :label="$t('userCenter.bu')" prop="formName">
                <el-input v-model="form.bu" placeholder disabled="disabled" />
              </el-form-item>
            </el-col>
          </el-row>
          <el-row>
            <el-col :span="8">
              <el-form-item :label="$t('userCenter.costCode')" prop="formName">
                <el-input v-model="form.costCode" placeholder disabled="disabled" />
              </el-form-item>
            </el-col>
            <el-col :span="8">
              <el-form-item :label="$t('userCenter.country')" prop="formName">
                <el-input v-model="form.country" placeholder disabled="disabled" />
              </el-form-item>
            </el-col>
            <el-col :span="8">
              <el-form-item :label="$t('userCenter.area')" prop="formName">
                <el-input v-model="form.area" placeholder disabled="disabled" />
              </el-form-item>
            </el-col>
          </el-row>
          <el-row>
            <el-col :span="8">
              <el-form-item :label="$t('userCenter.jobTitle')" prop="formName">
                <el-input v-model="form.jobTitle" placeholder disabled="disabled" />
              </el-form-item>
            </el-col>
            <el-col :span="8">
              <el-form-item :label="$t('userCenter.gradeDepart')" prop="formName">
                <el-input v-model="form.gradeDepart" placeholder disabled="disabled" />
              </el-form-item>
            </el-col>
            <el-col :span="8">
              <el-form-item :label="$t('userCenter.grade')" prop="formName">
                <el-input v-model="form.grade" placeholder disabled="disabled" />
              </el-form-item>
            </el-col>
          </el-row>
          <el-row>
            <el-col :span="8">
              <el-form-item :label="$t('userCenter.class')" prop="formName">
                <el-input v-model="form.class" placeholder disabled="disabled" />
              </el-form-item>
            </el-col>
            <el-col :span="8">
              <el-form-item :label="$t('userCenter.jobStatus')" prop="formName">
                <el-input v-model="form.jobStatus" placeholder disabled="disabled" />
              </el-form-item>
            </el-col>
            <el-col :span="8">
              <el-form-item :label="$t('userCenter.tel1')" prop="formName">
                <el-input v-model="form.mainlandExt" placeholder />
              </el-form-item>
            </el-col>
          </el-row>
          <el-row>
            <el-col :span="8">
              <el-form-item :label="$t('userCenter.tel2')" prop="formName">
                <el-input v-model="form.twExt" placeholder />
              </el-form-item>
            </el-col>
            <el-col :span="8">
              <el-form-item :label="$t('userCenter.tel3')" prop="formName">
                <el-input v-model="form.hkExt" placeholder />
              </el-form-item>
            </el-col>
            <el-col :span="8">
              <el-form-item :label="$t('userCenter.tel4')" prop="formName">
                <el-input v-model="form.foreignExt" placeholder />
              </el-form-item>
            </el-col>
          </el-row>
        </el-tab-pane>
      </el-tabs>
    </el-form>
    <div>
      <el-button type="primary" plain @click="save">{{$t('system.save')}}</el-button>
    </div>
  </div>
</template>

<script setup>
import { getInfo } from "@/api/login";
import { updateUserProfile } from "@/api/system/user";
const { proxy } = getCurrentInstance();
const active = proxy.$t("userCenter.tab1");
const active1 = proxy.$t("userCenter.tab2");

const form = ref({});
function init() {}
getInfo().then(res => {
  form.value = res.user;
  // form.value.phoneNumber = "+886918817198";
  form.value.phoneNumber = form.value.phoneNumber.replace(
    form.value.phoneNumber.slice(-8, -4),
    "*".repeat(4)
  );
});
function save() {
  updateUserProfile(form.value).then(res => {
    proxy.$modal.msgSuccess(proxy.$t("system.saveInfo"));
  });
}
init();
</script>

<style>
</style>