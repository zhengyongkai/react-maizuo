<template>
  <div class="social_container_mains">
    <div class="social_container_header">
      <search @search="onSearch" />
    </div>
    <div class="social_container_content" v-if="dataList.items">
      <div class="social_container_content_noempty">
        <div class="social_container_content_search">
          <el-checkbox-group v-model="checkList">
            <div class="social_container_search_title">
              <div>篩選條件</div>
              <div>
                <img src="@/assets/images/social/refresh.png" />
                <div>重置</div>
              </div>
            </div>
            <div>
              <div class="social_container_kind_title">類別</div>
              <div>
                <el-checkbox label="行動辦公室" />
                <el-checkbox label="资安防御" />
                <el-checkbox label="雲鋼運維" />
                <el-checkbox label="業務管理" />
                <el-checkbox label="開發管理" />
              </div>
            </div>
            <div>
              <div class="social_container_kind_title">主題</div>
              <div>
                <el-checkbox label="新人推薦" />
                <el-checkbox label="資安防禦" />
                <el-checkbox label="系統管理" />
              </div>
            </div>
            <div>
              <div class="social_container_kind_title">通用地區</div>
              <div>
                <el-checkbox label="台灣" />
                <el-checkbox label="中國大陸" />
                <el-checkbox label="海外（非台陸港）" />
              </div>
            </div>
          </el-checkbox-group>
        </div>
        <div class="social_container_content_main">
          <div class="social_container_content_main_items" v-if="dataList?.items.length !== 0">
            <div>
              <div>排序：熱門程度(由高至低)</div>
              <div><img src="@/assets/images/social/sequence.png" /></div>
            </div>
            <div class="social_container_content_item">
              <div
                class="social_container_content_main_item"
                @mouseover="current = i"
                v-for="(i, k) in dataList.items"
                :key="k"
              >
                <div class="social_container_content_main_item_top">
                  <img :src="i.img" />
                  <div>
                    <div>
                      <div>Super Notes郵箱申請</div>
                      <div v-show="current === i">
                        <span>前往</span>
                        <img src="@/assets/images/social/right.png" />
                      </div>
                    </div>
                    <div>資安防禦</div>
                  </div>
                </div>
                <div class="social_container_content_main_item_desc">
                  集團員工個人郵箱使用申請集團員工個人郵箱
                </div>
              </div>
            </div>
            <div class="social_container_content_pagination">
              <el-pagination
                background
                layout=" ->,total, sizes, prev, pager, next"
                :total="1000"
              />
            </div>
          </div>
          <div class="social_container_content_main_empty" v-else>
            <div>
              <img src="@/assets/images/social/empty.png" />
            </div>
            <div>抱歉，當前類別暫無數據</div>
            <div>請更換或清除條件再試</div>
          </div>
        </div>
      </div>
    </div>
    <div class="social_container_content_empty" v-else>
      <div>
        <img src="@/assets/images/social/empty.png" />
      </div>
      <div>抱歉，暫無符合“網路”的內容</div>
      <div>您可嘗試其他關鍵字重新搜尋，或參考以下熱門搜尋</div>
      <div>郵箱、O365、移動辦公、WIFI、資安防護、分機、SAP</div>
    </div>
  </div>
</template>

<script setup>
import teamsPic from '@/assets/images/social/teams.png'
import superNotesPic from '@/assets/images/social/supernotes.png'
import safePic from '@/assets/images/social/safe.png'
import wvdPic from '@/assets/images/social/wvd.png'
import Pic from '@/assets/images/social/03.png'
import search from '../components/search.vue'
const current = ref(null)
const checkList = ref([])
const dataList = ref({
  items: [
    {
      img: teamsPic
    },
    {
      img: superNotesPic
    },
    {
      img: safePic
    },
    {
      img: wvdPic
    },
    {
      img: Pic
    }
  ]
})

function onSearch(value) {
  if (value === '1') {
    dataList.value = {}
  } else {
    dataList.value.items = !value
      ? []
      : [{}, {}, {}, {}, {}, {}, {}, {}, {}, {}, {}, {}, {}, {}, {}]
  }
}
</script>

<style lang="scss" scoped>
@import '@/assets/styles/variables.module.scss';

$--social-padding: 0 120px;
$--border-sizing: border-box !important;

::v-deep .el-pagination.is-background .btn-next,
::v-deep .el-pagination.is-background .btn-pre {
  background-color: transparent;
}

::v-deep .el-pagination.is-background li.is-active {
  background-color: #3260c9;
}

::v-deep .el-checkbox-group {
  font-size: inherit;
  line-height: inherit;
}

::v-deep .el-checkbox__label {
  font-size: 14px;
  font-weight: 400;
  line-height: 22px;
  letter-spacing: 0em;
  text-align: left;
  color: #333333;
}

::v-deep .el-checkbox {
  .el-checkbox__input.is-checked .el-checkbox__inner {
    background-color: #3260c9;
    border-color: #3260c9;
  }
  .is-checked + .el-checkbox__label {
    color: inherit;
  }
  .el-checkbox__inner {
    width: 16px;
    height: 16px;
    border: 1px solid #727272;

    &::after {
      border-width: 2px;
      height: 8px;
      left: 5px;
    }
  }
}

::v-deep .el-checkbox__label {
  font-size: 14px;
  font-weight: 400;
  line-height: 22px;
  letter-spacing: 0em;
  text-align: left;
  color: #333333;
}

.social_container_mains {
  box-sizing: $--border-sizing;
  background: url('@/assets/images/social/formItem.png');
  background-size: 100% 100%;
  padding: $--social-padding;
  // padding-bottom: 84px;
  padding-top: 60px;
  .social_container_header_content {
    padding-top: 24px;
    // padding-bottom:0;
  }
  .social_container_header {
    // background: url('@/assets/images/social/work_banner.png');
    background-size: 100% 100%;
    width: 100%;
    // padding: $--social-padding;
    box-sizing: $--border-sizing;
  }

  .social_container_content,
  .social_container_content_empty {
    height: 604px;
    margin-top: 24px;
    // padding: $--social-padding;
    background: #fff;
    // height: 300px;
    border: 1px solid #dcdcdc;
    border-radius: 8px;
    width: 100%;

    .social_container_content_noempty {
      display: flex;
      height: 100%;
      .social_container_content_search {
        padding: 16px 24px 29px 16px;
        width: 180px;
        border-right: 1px solid #d9d9d9;
        height: 100%;

        .social_container_search_title {
          display: flex;
          align-items: center;
          > :first-child {
            font-size: 16px;
            font-weight: 700;
            line-height: 24px;
            letter-spacing: 0em;
            text-align: left;
            color: #333333;
          }

          > :last-child {
            display: flex;
            align-items: center;
            margin-left: auto;
            font-size: 12px;
            font-weight: 700;
            line-height: 18px;
            letter-spacing: 0em;
            text-align: left;
            color: #3260c9;
            img {
              width: 16px;
              margin-right: 4px;
            }
          }
        }
        .social_container_kind_title {
          margin-top: 24px;
          font-size: 14px;
          margin-bottom: 8px;
          font-weight: 400;
          line-height: 22px;
          letter-spacing: 0em;
          text-align: left;
          color: #727272;
        }
      }
      .social_container_content_main {
        position: relative;
        flex: 1;
        .social_container_content_main_items {
          display: flex;
          flex-direction: column;

          > :first-child {
            height: 50px;
            border-bottom: 1px solid #7272722e;
            display: flex;
            text-align: right;
            align-items: center;
            margin-left: auto;
            padding-right: 16px;
            font-size: 14px;
            font-weight: 400;
            line-height: 22px;
            letter-spacing: 0em;
            text-align: left;
            color: #333333;
            > :first-child {
              margin-right: 12px;
            }

            img {
              width: 24px;
              height: 24px;
              margin-top: 6px;
            }
          }
          > :last-child {
            flex: 1;
            overflow: auto;

            > div {
            }
          }

          .social_container_content_item {
            // margin-top: 16px;
            position: absolute;
            padding: 24px 16px 0 16px;
            // padding-bottom:50px;
            left: 0;
            right: 0;
            top: 50px;
            bottom: 64px;
            overflow: auto;
            display: grid;
            grid-template-columns: 1fr 1fr 1fr;
            grid-template-rows: 118px 118px;
            grid-column-gap: 17px;
            grid-row-gap: 24px;
            > div:hover {
              background: linear-gradient(96.79deg, #d3e6ff 1.6%, #ffffff 90.87%);
              box-shadow: 0px 6px 15px 0px #0000001a;
            }

            > div {
              cursor: pointer;
              border-radius: 4px;
              box-sizing: inherit;
              height: 118px;
              padding: 16px 14px 16px 16px;
              // border: 1px solid #dcdcdc;
              background: linear-gradient(186.12deg, #f1f7ff 1.79%, #f7faff 78.56%);
            }
            .social_container_content_main_item_top {
              height: 48px;
              display: flex;
              > img {
                height: 48px;
                // width: 48px;
                margin-right: 16px;
              }
              > div {
                flex: 1;

                > :first-child {
                  font-size: 14px;
                  font-weight: 700;
                  line-height: 22px;
                  letter-spacing: 0em;
                  text-align: left;
                  display: flex;

                  > :first-child {
                  }
                  > :last-child {
                    color: #3260c9;

                    text-align: right;
                    margin-left: auto;
                    img {
                      width: 12px;
                      height: 8px;
                    }
                  }
                }

                > :last-child {
                  height: 22px;
                  background-color: #fff;
                  font-size: 12px;
                  font-weight: 700;
                  line-height: 18px;
                  letter-spacing: 0em;
                  text-align: left;
                  width: 64px;
                  padding: 2px 8px;
                  border-radius: 4px;
                  color: #3260c9;
                  margin-top: 4px;
                }
              }
            }
            .social_container_content_main_item_desc {
              font-size: 14px;
              font-weight: 400;
              line-height: 22px;
              letter-spacing: 0em;
              text-align: left;
              color: #727272;
              margin-top: 16.89px;
            }
          }

          .social_container_content_pagination {
            position: absolute;
            left: 0;
            right: 26px;
            height: 64px;
            line-height: 64px;
            display: flex;
            align-items: center;
            bottom: 0;
            background: #fff;
            margin-left: auto;
            text-align: right;
            flex-direction: row-reverse;
          }
        }
        .social_container_content_main_empty {
          margin: 0 auto;
          text-align: center;
          img {
            margin-top: 147px;
            width: 96px;
            margin-bottom: 16px;
          }

          div {
            font-size: 14px;
            font-weight: 600;
            line-height: 22px;
            letter-spacing: 0em;
            text-align: center;
            color: #333333;
          }
        }
      }
    }
  }
  .social_container_content_empty {
    height: 329px;
    line-height: 329px;
    img {
      margin-top: 64px;
      width: 96px;
      margin-bottom: 16px;
    }
    div {
      font-size: 14px;
      font-weight: 600;
      line-height: 22px;
      letter-spacing: 0em;
      text-align: center;
      color: #333333;
    }

    > :last-child {
      margin-top: 12px;
      font-size: 14px;
      font-weight: 600;
      line-height: 19px;
      letter-spacing: 0em;
      text-align: center;
      color: #3260c9;
    }
  }
}
</style>
