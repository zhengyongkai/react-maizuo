<template>
  <div>首页</div>
</template>

<script setup name="Index">
</script>

<style scoped lang="scss">
</style>

