<template>
  <div class="app-container">
    <el-form :model="queryParams" ref="queryRef" :inline="true">
      <el-form-item label="系统名称" prop="serverName">
        <el-input
          v-model="queryParams.serverName"
          placeholder="请输入系统名称"
          clearable
          style="width: 200px"
          @keyup.enter="handleQuery"
        />
      </el-form-item>
      <el-form-item label="系统别名" prop="serverAlias">
        <el-input
          v-model="queryParams.serverAlias"
          placeholder="请输入系统别名"
          clearable
          style="width: 200px"
          @keyup.enter="handleQuery"
        />
      </el-form-item>
      <el-form-item>
        <el-button type="primary" icon="Search" @click="handleQuery">搜索</el-button>
        <el-button icon="Refresh" @click="resetQuery">重置</el-button>
      </el-form-item>
    </el-form>
    <el-row :gutter="10" class="mb8">
      <el-col :span="1.5">
        <el-button
          type="primary"
          plain
          icon="Plus"
          @click="handleAdd"
          v-hasPermi="['system:role:add']"
        >新增</el-button>
      </el-col>
      <el-col :span="1.5">
        <el-button
          type="danger"
          plain
          icon="Delete"
          :disabled="multiple"
          @click="handleDelete"
          v-hasPermi="['system:dict:remove']"
        >删除</el-button>
      </el-col>
    </el-row>
    <el-table
      v-loading="loading"
      :data="sysList"
      style="width: 100%;"
      @selection-change="handleSelectionChange"
    >
      <el-table-column type="selection" width="55" align="center" />

      <!-- <el-table-column type="index" width="50" label="序号" /> -->
      <el-table-column
        label="系统排序"
        align="center"
        prop="orderNum"
        :show-overflow-tooltip="true"
        width="100px"
      />
      <el-table-column label="系统名称" align="center" prop="serverName" :show-overflow-tooltip="true">
        <template #default="scope">
          <el-link
            type="primary"
            :underline="false"
            @click="handleUpdate(scope.row)"
          >{{scope.row.serverName}}</el-link>
        </template>
      </el-table-column>
      <el-table-column
        label="系统别名"
        align="center"
        prop="serverAlias"
        :show-overflow-tooltip="true"
      />

      <el-table-column
        label="服务秘钥"
        align="center"
        prop="serverSecret"
        :show-overflow-tooltip="true"
        width="350px"
      />
      <el-table-column label="icon" align="center" prop="logoUrl" :show-overflow-tooltip="true">
        <template #default="scope">
          <img v-if="scope.row.logoUrl" :src="scope.row.logoUrl" style="width:50px;height:50px" />
        </template>
      </el-table-column>

      <el-table-column
        label="系统描述"
        align="center"
        prop="description"
        :show-overflow-tooltip="true"
      />

      <el-table-column label="操作" align="center" class-name="small-padding fixed-width" width="200">
        <template #default="scope">
          <el-button
            link
            type="primary"
            icon="Document"
            @click="handleForm(scope.row)"
            v-hasPermi="['monitor:online:forceLogout']"
          >服务表单维护</el-button>
          <el-button
            link
            type="primary"
            icon="Delete"
            @click="handleDelete(scope.row)"
            v-hasPermi="['monitor:online:forceLogout']"
          >删除</el-button>
        </template>
      </el-table-column>
    </el-table>

    <pagination v-show="total > 0" :total="total" v-model:page="pageNum" v-model:limit="pageSize" />

    <el-dialog :title="title" v-model="open" width="800px" append-to-body>
      <el-form ref="formRef" :model="form" :rules="rules" label-width="150px">
        <el-form-item label="系统名称" prop="serverName">
          <el-input v-model="form.serverName" placeholder="请输入系统名称" />
        </el-form-item>
        <el-form-item label="系统名称-繁体" prop="serverName_zh_tw">
          <el-input v-model="form.serverName_zh_tw" placeholder="请输入系统名称" />
        </el-form-item>
        <el-form-item label="系统名称-英文" prop="serverName_en_us">
          <el-input v-model="form.serverName_en_us" placeholder="请输入系统名称" />
        </el-form-item>
        <el-form-item label="系统别名" prop="serverAlias">
          <el-input v-model="form.serverAlias" placeholder="请输入系统别名" />
        </el-form-item>
        <el-form-item label="系统描述" prop="description">
          <el-input v-model="form.description" type="textarea" placeholder="请输入表单描述" />
        </el-form-item>
        <el-form-item label="系统描述-繁体" prop="description">
          <el-input v-model="form.description_zh_tw" type="textarea" placeholder="请输入表单描述" />
        </el-form-item>
        <el-form-item label="系统描述-英文" prop="description">
          <el-input v-model="form.description_en_us" type="textarea" placeholder="请输入表单描述" />
        </el-form-item>
        <el-form-item label="排序" prop="orderNum">
          <!-- <el-input v-model="form.orderNum" placeholder="请输入表单描述" /> -->
          <el-input-number v-model="form.orderNum" :min="1" />
        </el-form-item>
        <el-form-item label="icon" prop="logoUrl">
          <ImageUpload :limit="1" :fileType="['png', 'jpg']" v-model:modelValue="form.logoUrl" />
        </el-form-item>
      </el-form>
      <template #footer>
        <div class="dialog-footer">
          <el-button type="primary" @click="submit">确 定</el-button>
          <el-button @click="open = false">取 消</el-button>
        </div>
      </template>
    </el-dialog>
  </div>
</template>

<script setup name="Online">
import { forceLogout, list as initData } from "@/api/monitor/online";
import {
  listPlatForm,
  addPlatForm,
  editPlatForm,
  delPlatForm
} from "@/api/tps/platform";
const { proxy } = getCurrentInstance();
const router = useRouter();

const sysList = ref([]);
const loading = ref(true);
const total = ref(0);
const pageNum = ref(1);
const pageSize = ref(10);

const queryParams = ref({
  ipaddr: undefined,
  userName: undefined
});

const open = ref(false);
const form = ref({});
const title = ref("");
const rules = {
  serverName: [
    { required: true, message: "系统名称不能为空", trigger: "blur" }
  ],
  serverName_zh_tw: [
    { required: true, message: "系统名称不能为空", trigger: "blur" }
  ],
  serverName_en_us: [
    { required: true, message: "系统名称不能为空", trigger: "blur" }
  ],
  orderNum: [{ required: true, message: "排序不能为空", trigger: "blur" }]
};
const ids = ref([]);
const multiple = ref(true);

/** 查询列表 */
function getList() {
  loading.value = true;
  listPlatForm(queryParams.value).then(response => {
    sysList.value = response.rows;
    total.value = response.total;
    loading.value = false;
  });
}
/** 搜索按钮操作 */
function handleQuery() {
  pageNum.value = 1;
  getList();
}
/** 重置按钮操作 */
function resetQuery() {
  proxy.resetForm("queryRef");
  handleQuery();
}

function handleSelectionChange(selection) {
  ids.value = selection.map(item => item.id);
  multiple.value = !selection.length;
}

function handleAdd() {
  title.value = "新增系统";
  open.value = true;
  form.value = {};
  proxy.resetForm("formRef");
  // form.value.logoUrl =
  //   "http://10.94.0.112:8080/profile/upload/2023/05/17/exNRQlHA1OMreatJAQ91 (2)_20230517090932A020.jpg";
}

function handleUpdate(row) {
  title.value = "编辑系统";
  open.value = true;
  form.value = Object.assign({}, row);
}

function handleDelete(row) {
  const id = row.id || ids.value;
  proxy.$modal
    .confirm("是否确认删除的数据项?")
    .then(function() {
      return delPlatForm(id);
    })
    .then(() => {
      getList();
      proxy.$modal.msgSuccess("删除成功");
    })
    .catch(() => {});
}

function handleForm(row) {
  router.push({
    path: "/tps/platform/form",
    query: {
      id: row.id
    }
  });
}

function submit() {
  proxy.$refs["formRef"].validate(valid => {
    let data = Object.assign({}, form.value);
    if (valid) {
      if (data.id) {
        editPlatForm(data).then(res => {
          proxy.$modal.msgSuccess("编辑成功");
          open.value = false;
          handleQuery();
        });
      } else {
        addPlatForm(data).then(res => {
          proxy.$modal.msgSuccess("新增成功");
          open.value = false;
          handleQuery();
        });
      }
    }
  });
}

getList();
</script>
