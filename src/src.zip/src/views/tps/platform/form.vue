<template>
  <div class="app-container">
    <el-row :gutter="10" class="mb8">
      <el-col :span="1.5">
        <el-button
          type="primary"
          plain
          icon="Plus"
          @click="handleAdd"
          v-hasPermi="['system:role:add']"
        >新增</el-button>
      </el-col>
      <el-col :span="1.5">
        <el-button
          type="danger"
          plain
          icon="Delete"
          :disabled="multiple"
          @click="handleDelete"
          v-hasPermi="['system:dict:remove']"
        >删除</el-button>
      </el-col>
    </el-row>
    <el-table
      v-loading="loading"
      :data="sysList"
      style="width: 100%;"
      @selection-change="handleSelectionChange"
    >
      <el-table-column type="selection" width="55" align="center" />

      <!-- <el-table-column type="index" width="50" label="序号" /> -->
      <!-- <el-table-column
        label="表单排序"
        align="center"
        prop="orderNum"
        :show-overflow-tooltip="true"
        width="100px"
      />-->
      <el-table-column label="表单名称" align="center" prop="formName" :show-overflow-tooltip="true">
        <template #default="scope">
          <el-link
            type="primary"
            :underline="false"
            @click="handleUpdate(scope.row)"
          >{{scope.row.formName}}</el-link>
        </template>
      </el-table-column>
      <el-table-column
        label="热度"
        align="center"
        prop="visitCount"
        :show-overflow-tooltip="true"
        width="50"
      />
      <el-table-column label="icon" align="center" prop="logoUrl" :show-overflow-tooltip="true">
        <template #default="scope">
          <img v-if="scope.row.logoUrl" :src="scope.row.logoUrl" style="width:50px;height:50px" />
        </template>
      </el-table-column>

      <el-table-column label="保存表单地址" align="center" prop="url" :show-overflow-tooltip="true" />
      <el-table-column
        label="查询表单地址"
        align="center"
        prop="myFormUrl"
        :show-overflow-tooltip="true"
      />
      <el-table-column
        label="表单描述"
        align="center"
        prop="description"
        :show-overflow-tooltip="true"
      />
      <el-table-column label="操作" align="center" class-name="small-padding fixed-width" width="200">
        <template #default="scope">
          <el-button
            link
            type="primary"
            icon="Document"
            @click="handleForm(scope.row)"
            v-hasPermi="['monitor:online:forceLogout']"
          >表单配置</el-button>
          <el-button
            link
            type="primary"
            icon="Delete"
            @click="handleDelete(scope.row)"
            v-hasPermi="['monitor:online:forceLogout']"
          >删除</el-button>
        </template>
      </el-table-column>
    </el-table>

    <pagination
      v-show="total > 0"
      :total="total"
      v-model:page="queryParams.pageNum"
      v-model:limit="queryParams.pageSize"
      @pagination="getList"
    />

    <el-dialog :title="title" v-model="open" width="80%" append-to-body>
      <el-form ref="formRef" :model="form" :rules="rules" label-width="130px">
        <el-row>
          <el-col :span="8">
            <el-form-item label="表单名称" prop="formName">
              <el-input v-model="form.formName" placeholder="请输入表单名称" />
            </el-form-item>
          </el-col>
          <el-col :span="8">
            <el-form-item label="表单名称-繁体" prop="formName_zh_tw">
              <el-input v-model="form.formName_zh_tw" placeholder="请输入表单名称" />
            </el-form-item>
          </el-col>
          <el-col :span="8">
            <el-form-item label="表单名称-英文" prop="formName_en_us">
              <el-input v-model="form.formName_en_us" placeholder="请输入表单名称" />
            </el-form-item>
          </el-col>
        </el-row>
        <!-- <el-row>
          <el-col :span="8">
            <el-form-item label="表单分组" prop="groupName">
              <el-input v-model="form.groupName" placeholder="请输入表单分组" />
            </el-form-item>
          </el-col>
          <el-col :span="8">
            <el-form-item label="表单分组-繁体" prop="groupName_zh_tw">
              <el-input v-model="form.groupName_zh_tw" placeholder="请输入表单分组" />
            </el-form-item>
          </el-col>

          <el-col :span="8">
            <el-form-item label="表单分组-英文" prop="groupName_en_us">
              <el-input v-model="form.groupName_en_us" placeholder="请输入表单分组" />
            </el-form-item>
          </el-col>
        </el-row>-->

        <el-form-item label="保存表单地址" prop="url">
          <el-input v-model="form.url" type="textarea" placeholder="请输入表单地址" />
        </el-form-item>
        <el-form-item label="查询表单地址" prop="myFormUrl">
          <el-input v-model="form.myFormUrl" type="textarea" placeholder="请输入表单地址" />
        </el-form-item>
        <el-row>
          <el-col :span="8">
            <el-form-item label="业务类别" prop="bizType">
              <el-input v-model="form.bizType" placeholder="请输入业务类别" />
            </el-form-item>
          </el-col>
          <el-col :span="8">
            <el-form-item label="业务类别-繁体" prop="bizType_zh_tw">
              <el-input v-model="form.bizType_zh_tw" placeholder="请输入业务类别" />
            </el-form-item>
          </el-col>

          <el-col :span="8">
            <el-form-item label="业务类别-英文" prop="bizType_en_us">
              <el-input v-model="form.bizType_en_us" placeholder="请输入业务类别" />
            </el-form-item>
          </el-col>
        </el-row>
        <el-row>
          <el-col :span="8">
            <el-form-item label="用户申请群" prop="applyUserGroup">
              <el-input v-model="form.applyUserGroup" type="textarea" placeholder="请输入用户申请群" />
            </el-form-item>
          </el-col>
          <el-col :span="8">
            <el-form-item label="用户申请群-繁体" prop="applyUserGroup_zh_tw">
              <el-input v-model="form.applyUserGroup_zh_tw" type="textarea" placeholder="请输入用户申请群" />
            </el-form-item>
          </el-col>
          <el-col :span="8">
            <el-form-item label="用户申请群-英文" prop="applyUserGroup_en_us">
              <el-input v-model="form.applyUserGroup_en_us" type="textarea" placeholder="请输入用户申请群" />
            </el-form-item>
          </el-col>
        </el-row>
        <el-row>
          <el-col :span="8">
            <el-form-item label="关键字" prop="tags">
              <el-input v-model="form.tags" placeholder="请输入关键字" />
            </el-form-item>
          </el-col>
          <el-col :span="8">
            <el-form-item label="关键字-繁体" prop="tags_zh_tw">
              <el-input v-model="form.tags_zh_tw" placeholder="请输入关键字" />
            </el-form-item>
          </el-col>
          <el-col :span="8">
            <el-form-item label="关键字-英文" prop="tags_en_us">
              <el-input v-model="form.tags_en_us" placeholder="请输入关键字" />
            </el-form-item>
          </el-col>
        </el-row>

        <!-- <el-form-item label="关键字" prop="tags">
          <el-tag
            v-for="tag in form.tags"
            :key="tag"
            closable
            :disable-transitions="false"
            @close="handleClose(tag)"
            style="margin-right:10px"
          >{{ tag }}</el-tag>
          <el-input
            v-if="inputVisible"
            ref="InputRef"
            v-model="inputValue"
            style="width:100px"
            size="small"
            @keyup.enter="handleInputConfirm"
            @blur="handleInputConfirm"
          />
          <el-button v-else class="button-new-tag ml-1" size="small" @click="showInput">+ 新标签</el-button>
        </el-form-item>-->
        <el-row>
          <el-col :span="8">
            <el-form-item label="附件要求" prop="attachmentRequire">
              <el-input v-model="form.attachmentRequire" type="textarea" placeholder="请输入附件要求" />
            </el-form-item>
          </el-col>
          <el-col :span="8">
            <el-form-item label="附件要求-繁体" prop="attachmentRequire_zh_tw">
              <el-input
                v-model="form.attachmentRequire_zh_tw"
                type="textarea"
                placeholder="请输入附件要求"
              />
            </el-form-item>
          </el-col>

          <el-col :span="8">
            <el-form-item label="附件要求-英文" prop="attachmentRequire_en_us">
              <el-input
                v-model="form.attachmentRequire_en_us"
                type="textarea"
                placeholder="请输入附件要求"
              />
            </el-form-item>
          </el-col>
        </el-row>
        <el-row>
          <el-col :span="8">
            <el-form-item label="表单描述" prop="description">
              <el-input v-model="form.description" type="textarea" placeholder="请输入表单描述" />
            </el-form-item>
          </el-col>
          <el-col :span="8">
            <el-form-item label="表单描述-繁体" prop="description_zh_tw">
              <el-input v-model="form.description_zh_tw" type="textarea" placeholder="请输入表单描述" />
            </el-form-item>
          </el-col>
          <el-col :span="8">
            <el-form-item label="表单描述-英文" prop="description_en_us">
              <el-input v-model="form.description_en_us" type="textarea" placeholder="请输入表单描述" />
            </el-form-item>
          </el-col>
        </el-row>
        <!-- 
        <el-form-item label="排序" prop="orderNum">
          <el-input-number v-model="form.orderNum" :min="1" />
        </el-form-item>-->
        <el-form-item label="icon" prop="logoUrl">
          <ImageUpload
            :limit="1"
            :fileType="['png', 'jpg']"
            v-model:modelValue="form.logoUrl"
            tip="建议比例为1：1"
          />
          <br />
        </el-form-item>
      </el-form>
      <template #footer>
        <div class="dialog-footer">
          <el-button type="primary" @click="submit">确 定</el-button>
          <el-button @click="open = false">取 消</el-button>
        </div>
      </template>
    </el-dialog>
  </div>
</template>

<script setup name="Online">
import { forceLogout, list as initData } from "@/api/monitor/online";
import { listForm, addForm, editForm, delForm } from "@/api/tps/platform";
const { proxy } = getCurrentInstance();
const router = useRouter();
const route = useRoute();
const sysList = ref([]);
const loading = ref(true);
const total = ref(0);

const queryParams = ref({
  pageNum: 1,
  pageSize: 10
});
const open = ref(false);
const form = ref({});
const title = ref("");
const rules = {
  formName: [{ required: true, message: "表单名称不能为空", trigger: "blur" }],
  formName_zh_tw: [
    { required: true, message: "表单名称不能为空", trigger: "blur" }
  ],

  formName_en_us: [
    { required: true, message: "表单名称不能为空", trigger: "blur" }
  ],
  groupName: [{ required: true, message: "表单分組不能为空", trigger: "blur" }],
  groupName_zh_tw: [
    { required: true, message: "表单分組不能为空", trigger: "blur" }
  ],
  groupName_en_us: [
    { required: true, message: "表单分組不能为空", trigger: "blur" }
  ],

  url: [{ required: true, message: "表单地址不能为空", trigger: "blur" }],

  orderNum: [{ required: true, message: "排序不能为空", trigger: "blur" }],
  logoUrl: [{ required: true, message: "icon不能为空", trigger: "change" }]
};
const ids = ref([]);
const multiple = ref(true);
const serverId = route.query.id;

const inputValue = ref("");

const inputVisible = ref(false);
const InputRef = ref(null);
/** 查询列表 */
function getList() {
  // pageNum.value = 1;

  loading.value = true;
  queryParams.value.serverId = serverId;
  // ''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
  listForm(queryParams.value).then(response => {
    sysList.value = response.rows;
    total.value = response.total;
    loading.value = false;
  });
}

function handleSelectionChange(selection) {
  ids.value = selection.map(item => item.id);
  multiple.value = !selection.length;
}

function handleAdd() {
  title.value = "新增表单";
  open.value = true;
  form.value = {};
  proxy.resetForm("formRef");
  // form.value.logoUrl =
  //   "http://10.94.0.112:8080/profile/upload/2023/05/17/exNRQlHA1OMreatJAQ91 (2)_20230517090932A020.jpg";
}

function handleUpdate(row) {
  title.value = "编辑表单";
  open.value = true;
  form.value = Object.assign({}, row);
}

function handleDelete(row) {
  const id = row.id || ids.value;
  proxy.$modal
    .confirm("是否确认删除的数据项?")
    .then(function() {
      return delForm(id);
    })
    .then(() => {
      getList();
      proxy.$modal.msgSuccess("删除成功");
    })
    .catch(() => {});
}

function submit() {
  // console.log("form", form.value);
  proxy.$refs["formRef"].validate(valid => {
    let data = Object.assign({}, form.value);
    data.serverId = serverId;
    if (valid) {
      if (data.id) {
        editForm(data).then(res => {
          proxy.$modal.msgSuccess("编辑成功");
          open.value = false;
          getList();
        });
      } else {
        addForm(data).then(res => {
          proxy.$modal.msgSuccess("新增成功");
          open.value = false;
          getList();
        });
      }
    }
  });
}

function handleForm(row) {
  router.push({
    path: "/tps/platform/formConfig/index",
    query: {
      id: row.id
    }
  });
}

function handleClose(tag) {
  form.value.tags.splice(form.value.tags.indexOf(tag), 1);
}

function showInput() {
  inputVisible.value = true;
  nextTick(() => {
    InputRef.value.focus();
  });
}

function handleInputConfirm() {
  if (inputValue.value) {
    form.value.tags.push(inputValue.value);
  }
  inputVisible.value = false;
  inputValue.value = "";
}

getList();
</script>
