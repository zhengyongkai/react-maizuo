<template>
  <div class="app-container">
    <el-row :gutter="20">
      <!--部门数据-->
      <el-col :span="8" :xs="24">
        <el-row :gutter="10" class="mb8">
          <el-col :span="1.5">
            <el-button
              type="primary"
              plain
              icon="Plus"
              @click="handleAdd"
              v-hasPermi="['system:role:add']"
            >新增</el-button>
          </el-col>
        </el-row>
        <div>
          <el-tree
            :data="treeData"
            :props="{label:'content',children:'children'}"
            :default-expand-all="true"
            :expand-on-click-node="false"
          >
            <template #default="{ node, data }">
              <div class="custom-tree-node">
                <selfTooltip :textValue="node.label" style="width:80%">
                  <!-- <span @click="editNode(data)" style="width:80%">{{ node.label }}</span> -->
                </selfTooltip>
                <span>
                  <el-icon color="#409eff" @click="addNode(data)" :size="16">
                    <CirclePlus />
                  </el-icon>
                  <el-icon
                    style="margin-left: 8px"
                    color="#409eff"
                    :size="16"
                    @click="editNode(data)"
                  >
                    <Edit />
                  </el-icon>
                  <el-icon
                    style="margin-left: 8px"
                    color="#f56c6c"
                    :size="16"
                    @click="delNode(data)"
                  >
                    <Delete />
                  </el-icon>
                </span>
              </div>
            </template>
          </el-tree>
        </div>
      </el-col>
      <el-col :span="16" :xs="24">
        <el-card class="box-card">
          <!-- <div style="padding:20px 20px;font-weight:600;font-size:16px">{{title}}</div> -->
          <template #header>
            <div class="card-header">
              <span style="font-weight:600;font-size:16px">{{title}}</span>
            </div>
          </template>
          <el-form ref="formRef" :model="form" :rules="rules" label-width="100px">
            <el-form-item label="父节点" prop="parentId">
              <el-tree-select
                v-model="form.parentId"
                :data="treeData"
                check-strictly
                :render-after-expand="false"
                show-checkbox
                :props="{label:'content',children:'children'}"
                :default-expand-all="true"
                node-key="id"
                :disabled="false"
              />
              <span>&nbsp;&nbsp;( 父节点为空时，既是根节点 )</span>
            </el-form-item>
            <!-- <el-form-item label="父节点" prop="parentNode">
          <el-input v-model="form.parentNode" placeholder="请输入问题" disabled />
            </el-form-item>-->
            <el-form-item label="问题" prop="content">
              <el-input v-model="form.content" placeholder="请输入问题" type="textarea" />
            </el-form-item>
            <el-form-item label="问题-繁体" prop="content_zh_tw">
              <el-input v-model="form.content_zh_tw" placeholder="请输入问题" type="textarea" />
            </el-form-item>
            <el-form-item label="问题-英文" prop="content_en_us">
              <el-input v-model="form.content_en_us" placeholder="请输入问题" type="textarea" />
            </el-form-item>
            <el-form-item label="最后节点" prop="leaf">
              <el-radio-group v-model="form.leaf" @change="form.option = []">
                <el-radio :label="true" size="large">是</el-radio>
                <el-radio :label="false" size="large">否</el-radio>
              </el-radio-group>
            </el-form-item>
            <el-form-item label="排序" prop="orderNum">
              <!-- <el-input v-model="form.orderNum" placeholder="请输入表单描述" /> -->
              <el-input-number v-model="form.orderNum" :min="1" />
            </el-form-item>
          </el-form>

          <div class="dialog-footer">
            <el-button type="primary" @click="submit">确 定</el-button>
            <el-button @click="router.go(-1)">取 消</el-button>
          </div>
        </el-card>
      </el-col>
    </el-row>
    <!-- <el-dialog :title="title" v-model="open" width="600px" append-to-body>
      <el-form ref="formRef" :model="form" :rules="rules" label-width="80px">
        <el-form-item label="父节点" prop="parentId">
          <el-tree-select
            v-model="form.parentId"
            :data="treeData"
            check-strictly
            :render-after-expand="false"
            show-checkbox
            :props="{label:'content',children:'children'}"
            :default-expand-all="true"
            node-key="id"
            :disabled="false"
          />
        </el-form-item>      
        <el-form-item label="问题" prop="content">
          <el-input v-model="form.content" placeholder="请输入问题" />
        </el-form-item>
        <el-form-item label="问题-繁体" prop="content_zh_tw">
          <el-input v-model="form.content_zh_tw" placeholder="请输入问题" />
        </el-form-item>
        <el-form-item label="问题-英文" prop="content_en_us">
          <el-input v-model="form.content_en_us" placeholder="请输入问题" />
        </el-form-item>
        <el-form-item label="最后节点" prop="leaf">
          <el-radio-group v-model="form.leaf" @change="form.option = []">
            <el-radio :label="true" size="large">是</el-radio>
            <el-radio :label="false" size="large">否</el-radio>
          </el-radio-group>
        </el-form-item>
        <el-form-item label="排序" prop="orderNum">
          <el-input-number v-model="form.orderNum" :min="1" />
        </el-form-item>
      </el-form>
      <template #footer>
        <div class="dialog-footer">
          <el-button type="primary" @click="submit">确 定</el-button>
          <el-button @click="open = false">取 消</el-button>
        </div>
      </template>
    </el-dialog>-->
  </div>
</template>

<script setup>
import {
  getQaTree,
  addQaTree,
  editQaTree,
  delQaTree,
  getListQa
} from "@/api/tps/qa";
const { proxy } = getCurrentInstance();
const router = useRouter();

const sysList = ref([]);
const loading = ref(true);
const total = ref(0);
const pageNum = ref(1);
const pageSize = ref(10);

const options = ref([
  { name: "XXX表单", value: "1" },
  { name: "YYY表单", value: "2" }
]);

const qeOptions = ["model1", "model2"];
const seOptions = ref([]);
const open = ref(false);
const form = ref({
  leaf: false,
  parentId: ""
});
const title = ref("");
let rules = {
  content: [{ required: true, message: "问题不能为空", trigger: "blur" }],
  content_zh_tw: [{ required: true, message: "问题不能为空", trigger: "blur" }],

  content_en_us: [{ required: true, message: "问题不能为空", trigger: "blur" }],

  parentId: [
    {
      required: false,
      message: "父节点",
      trigger: "change"
    }
  ]
};
const ids = ref([]);
const multiple = ref(true);
const treeData = ref([]);
/** 查询列表 */
function getList() {
  // loading.value = true;
  // getListQa({ pageSize: 0 }).then(response => {
  //   sysList.value = response.rows;
  //   // total.value = response.total;
  //   loading.value = false;
  // });
  getTree();
}

function qeChange(value) {
  console.log("va", value);
  form.value.option = [];
  if (value == "model1") {
    seOptions.value = ["style1", "style2", "style3", "style4"];
  } else if (value == "model2") {
    seOptions.value = ["style5"];
  }
}
function getTree() {
  form.value = {};
  getQaTree().then(res => {
    if (res.data) {
      treeData.value = res.data;
      // rules.parentId[0].required = true;
    } else {
      // rules.parentId[0].required = false;
      treeData.value = [];
    }
  });
}

function handleSelectionChange(selection) {
  ids.value = selection.map(item => item.id);
  multiple.value = !selection.length;
}

function handleAdd(data) {
  title.value = "新增智能问答";
  open.value = true;
  form.value = {};
  proxy.resetForm("formRef");
  form.value.leaf = false;
  form.value.parentId = "";
  // form.value.parentNode = "根节点";

  // form.value.logoUrl =
  //   "http://10.94.0.112:8080/profile/upload/2023/05/17/exNRQlHA1OMreatJAQ91 (2)_20230517090932A020.jpg";
}
function addNode(data) {
  title.value = "新增智能问答";
  open.value = true;
  form.value = {};
  proxy.resetForm("formRef");
  form.value.leaf = false;
  form.value.parentId = data.id;

  // form.value.logoUrl =
  //   "http://10.94.0.112:8080/profile/upload/2023/05/17/exNRQlHA1OMreatJAQ91 (2)_20230517090932A020.jpg";
}

function editNode(row) {
  title.value = "修改智能问答";
  open.value = true;
  console.log("row", row, row);
  form.value = Object.assign({}, row);
  // form.value = JSON.parse(JSON.stringify(row));

  // if (form.value.parentId == 0) {
  //   form.value.parentId = "";
  // }
}

function delNode(row) {
  const id = row.id || ids.value;
  proxy.$modal
    .confirm("是否确认删除的数据项?")
    .then(function() {
      return delQaTree(id);
    })
    .then(() => {
      getList();
      proxy.$modal.msgSuccess("删除成功");
    })
    .catch(() => {});
}

function submit() {
  proxy.$refs["formRef"].validate(valid => {
    let data = Object.assign({}, form.value);
    // return;
    if (valid) {
      if (data.id) {
        editQaTree(data).then(res => {
          proxy.$modal.msgSuccess("编辑成功");
          open.value = false;
          getList();
        });
      } else {
        addQaTree(data).then(res => {
          proxy.$modal.msgSuccess("新增成功");
          open.value = false;
          getList();
        });
      }
    }
  });
}

getList();
</script>

<style lang='scss' scoped>
.custom-tree-node {
  flex: 1;
  display: flex;
  align-items: center;
  justify-content: space-between;
  font-size: 14px;
  padding-right: 8px;
  overflow: hidden;
  #title {
    width: 80%;
    // white-space: nowrap;
    text-overflow: ellipsis;
    overflow: hidden;
    // word-break: break-all;
    // flex-wrap: wrap;
  }
  #test {
    display: flex;
    align-items: center;
    justify-content: center;
  }
}
</style>