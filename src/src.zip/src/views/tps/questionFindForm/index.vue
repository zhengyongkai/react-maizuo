<template>
  <div class="app-container">
    <el-row :gutter="20">
      <!--部门数据-->
      <el-col :span="6" :xs="24">
        <div>
          <el-tree
            :data="treeData"
            :props="{label:'questionName',children:'children'}"
            :default-expand-all="true"
          >
            <template #default="{ node, data }">
              <div class="custom-tree-node">
                <span>{{ node.label }}</span>
                <span>
                  <el-icon color="#409eff" @click="addNode(node)" :size="20">
                    <CirclePlus />
                  </el-icon>
                  <el-icon style="margin-left: 8px" color="#409eff" :size="20" @click="edit(node)">
                    <Edit />
                  </el-icon>
                  <el-icon
                    style="margin-left: 8px"
                    color="#f56c6c"
                    :size="20"
                    @click="handleDelete(node)"
                  >
                    <Delete />
                  </el-icon>
                </span>
              </div>
            </template>
          </el-tree>
        </div>
      </el-col>
      <el-col :span="18" :xs="24">
        <el-row :gutter="10" class="mb8">
          <el-col :span="1.5">
            <el-button
              type="primary"
              plain
              icon="Plus"
              @click="handleAdd"
              v-hasPermi="['system:role:add']"
            >新增</el-button>
          </el-col>
          <el-col :span="1.5">
            <el-button
              type="danger"
              plain
              icon="Delete"
              :disabled="multiple"
              @click="handleDelete"
              v-hasPermi="['system:dict:remove']"
            >删除</el-button>
          </el-col>
        </el-row>
        <el-table
          v-loading="loading"
          :data="sysList"
          style="width: 100%;"
          @selection-change="handleSelectionChange"
        >
          <el-table-column type="selection" width="55" align="center" />

          <!-- <el-table-column type="index" width="50" label="序号" /> -->
          <el-table-column
            label="问题"
            align="center"
            prop="questionName"
            :show-overflow-tooltip="true"
          >
            <template #default="scope">
              <el-link
                type="primary"
                :underline="false"
                @click="handleUpdate(scope.row)"
              >{{scope.row.questionName}}</el-link>
            </template>
          </el-table-column>
          <el-table-column
            label="父值依据"
            align="center"
            prop="bindValue"
            :show-overflow-tooltip="true"
          />
          <el-table-column label="问题值" align="center" prop="option" :show-overflow-tooltip="true">
            <template #default="scope">
              <div v-for="(item,index) in scope.row.option" :key="index">值{{index+1}}:{{item.value}}</div>
            </template>
          </el-table-column>

          <el-table-column
            label="父节点"
            align="center"
            prop="parentId"
            :show-overflow-tooltip="true"
          />
          <el-table-column
            label="问题样式"
            align="center"
            prop="questionStyle"
            :show-overflow-tooltip="true"
          />

          <el-table-column
            label="操作"
            align="center"
            class-name="small-padding fixed-width"
            width="100"
          >
            <template #default="scope">
              <el-button
                link
                type="primary"
                icon="Delete"
                @click="handleDelete(scope.row)"
                v-hasPermi="['monitor:online:forceLogout']"
              >删除</el-button>
            </template>
          </el-table-column>
        </el-table>

        <!-- <pagination
          v-show="total > 0"
          :total="total"
          v-model:page="pageNum"
          v-model:limit="pageSize"
        />-->
      </el-col>
    </el-row>
    <el-dialog :title="title" v-model="open" width="600px" append-to-body>
      <el-form ref="formRef" :model="form" :rules="rules" label-width="80px">
        <el-form-item label="父节点" prop="parentId">
          <el-tree-select
            v-model="form.parentId"
            :data="treeData"
            check-strictly
            :render-after-expand="false"
            show-checkbox
            :props="{label:'questionName',children:'children'}"
            :default-expand-all="true"
            node-key="id"
          />
        </el-form-item>
        <el-form-item label="父值依据" prop="bindValue">
          <el-input v-model="form.bindValue" placeholder="请输入父值依据" />
        </el-form-item>
        <el-form-item label="最后节点" prop="leaf">
          <el-radio-group v-model="form.leaf" @change="form.option = []">
            <el-radio :label="true" size="large">是</el-radio>
            <el-radio :label="false" size="large">否</el-radio>
          </el-radio-group>
        </el-form-item>

        <el-form-item label="问题" prop="questionName">
          <el-input v-model="form.questionName" type="textarea" placeholder="请输入问题" />
        </el-form-item>
        <el-form-item label="问题样式" prop="questionStyle">
          <el-select
            v-model="form.questionStyle"
            class="m-2"
            placeholder="选择选项样式"
            @change="qeChange"
          >
            <el-option v-for="it in qeOptions" :key="it" :label="it" :value="it" />
          </el-select>
        </el-form-item>
        <el-form-item label="问题值" prop="option" v-if="!form.leaf">
          <selfMultiline v-model:modelValue="form.option" :options="seOptions" />
          <!-- <el-input v-model="form.optionValue" type="textarea" placeholder="请输入问题值" /> -->
        </el-form-item>
        <el-form-item label="表单范围" prop="option" v-else>
          <el-select v-model="form.option" multiple placeholder="Select" style="width: 240px">
            <el-option v-for="item in options" :key="item" :label="item.name" :value="item" />
          </el-select>
        </el-form-item>
      </el-form>
      <template #footer>
        <div class="dialog-footer">
          <el-button type="primary" @click="submit">确 定</el-button>
          <el-button @click="open = false">取 消</el-button>
        </div>
      </template>
    </el-dialog>
  </div>
</template>

<script setup>
import {
  findFormTree,
  addFindForm,
  editFindForm,
  delFindForm,
  listFindForm
} from "@/api/tps/questionFindForm";
const { proxy } = getCurrentInstance();
const router = useRouter();

const sysList = ref([]);
const loading = ref(true);
const total = ref(0);
const pageNum = ref(1);
const pageSize = ref(10);

const options = ref([
  { name: "XXX表单", value: "1" },
  { name: "YYY表单", value: "2" }
]);

const qeOptions = ["model1", "model2"];
const seOptions = ref([]);
const open = ref(false);
const form = ref({
  leaf: false
});
const title = ref("");
let rules = {
  questionName: [{ required: true, message: "问题不能为空", trigger: "blur" }],
  parentId: [
    {
      required: false,
      message: "父节点",
      trigger: "change"
    }
  ]
};
const ids = ref([]);
const multiple = ref(true);
const treeData = ref({});
/** 查询列表 */
function getList() {
  loading.value = true;
  listFindForm({ pageSize: 0 }).then(response => {
    sysList.value = response.rows;
    // total.value = response.total;
    loading.value = false;
  });
  getTree();
}

function qeChange(value) {
  console.log("va", value);
  form.value.option = [];
  if (value == "model1") {
    seOptions.value = ["style1", "style2", "style3", "style4"];
  } else if (value == "model2") {
    seOptions.value = ["style5"];
  }
}
function getTree() {
  findFormTree().then(res => {
    if (res.data) {
      treeData.value = res.data;
      // rules.parentId[0].required = true;
    } else {
      // rules.parentId[0].required = false;
      treeData.value = [];
    }
  });
}

function handleSelectionChange(selection) {
  ids.value = selection.map(item => item.id);
  multiple.value = !selection.length;
}

function handleAdd() {
  title.value = "新增表单路径";
  open.value = true;
  form.value = {};
  form.value.option = [{ name: "", value: "", style: "" }];
  form.value.leaf = false;
  proxy.resetForm("formRef");

  // form.value.logoUrl =
  //   "http://10.94.0.112:8080/profile/upload/2023/05/17/exNRQlHA1OMreatJAQ91 (2)_20230517090932A020.jpg";
}

function handleUpdate(row) {
  title.value = "修改表单路径";
  open.value = true;
  // form.value = Object.assign({}, row);
  form.value = JSON.parse(JSON.stringify(row));
  if (form.value.parentId == 0) {
    form.value.parentId = "";
  }
}

function handleDelete(row) {
  const id = row.id || ids.value;
  proxy.$modal
    .confirm("是否确认删除的数据项?")
    .then(function() {
      return delFindForm(id);
    })
    .then(() => {
      getList();
      proxy.$modal.msgSuccess("删除成功");
    })
    .catch(() => {});
}

function handleForm(row) {
  router.push({
    path: "/tps/platform/form",
    query: {
      id: row.id
    }
  });
}

function submit() {
  proxy.$refs["formRef"].validate(valid => {
    let data = Object.assign({}, form.value);

    console.log("data", data);
    // return;
    if (valid) {
      if (data.id) {
        editFindForm(data).then(res => {
          proxy.$modal.msgSuccess("编辑成功");
          open.value = false;
          getList();
        });
      } else {
        addFindForm(data).then(res => {
          proxy.$modal.msgSuccess("新增成功");
          open.value = false;
          getList();
        });
      }
    }
  });
}

getList();
</script>

<style lang='scss' scoped>
.custom-tree-node {
  flex: 1;
  display: flex;
  align-items: center;
  justify-content: space-between;
  font-size: 14px;
  padding-right: 8px;
  overflow: hidden;
  #title {
    width: 80%;
    // white-space: nowrap;
    text-overflow: ellipsis;
    overflow: hidden;
    // word-break: break-all;
    // flex-wrap: wrap;
  }
  #test {
    display: flex;
    align-items: center;
    justify-content: center;
  }
}
</style>