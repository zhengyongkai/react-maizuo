<template>
   <div class="app-container">
        <el-tabs
            v-model="activeName"

            @tab-click="handleClick"
        >
            <el-tab-pane label="主题" name="kind"></el-tab-pane>
            <el-tab-pane label="种类" name="theme"></el-tab-pane>
        </el-tabs>
        <div>
            <kind  v-if="activeName === 'kind'"/>
            <theme v-if="activeName === 'theme'"/>
        </div>
   </div>
</template>

<script setup name="form">
import kind from  './kind'
import theme from  './theme'

const activeName = ref('kind')

</script>
