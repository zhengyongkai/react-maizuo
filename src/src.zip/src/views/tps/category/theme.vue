<template>
  <el-form
    :model="queryParams"
    ref="queryRef"
    :inline="true"
    v-show="showSearch"
    label-width="68px"
  >
    <el-form-item label="种类名称" prop="name">
      <el-input
        v-model="queryParams.name"
        placeholder="请输入种类名称"
        clearable
        style="width: 240px"
        @keyup.enter="handleQuery"
      />
    </el-form-item>
    <el-form-item>
      <el-button type="primary" icon="Search" @click="handleQuery">搜索</el-button>
      <el-button icon="Refresh" @click="resetQuery">重置</el-button>
    </el-form-item>
  </el-form>

  <el-row :gutter="10" class="mb8">
    <el-col :span="1.5">
      <el-button
        type="primary"
        plain
        icon="Plus"
        @click="handleAdd"
        v-hasPermi="['system:config:add']"
      >新增</el-button>
    </el-col>
    <el-col :span="1.5">
      <el-button
        type="success"
        plain
        icon="Edit"
        :disabled="single"
        @click="handleUpdate"
        v-hasPermi="['system:config:edit']"
      >修改</el-button>
    </el-col>
    <el-col :span="1.5">
      <el-button
        type="danger"
        plain
        icon="Delete"
        :disabled="multiple"
        @click="handleDelete"
        v-hasPermi="['system:config:remove']"
      >删除</el-button>
    </el-col>

    <right-toolbar v-model:showSearch="showSearch" @queryTable="getList"></right-toolbar>
  </el-row>

  <el-table v-loading="loading" :data="configList" @selection-change="handleSelectionChange">
    <el-table-column type="selection" width="55" align="center" />
    <el-table-column label="名称（简体）" align="center" prop="name" :show-overflow-tooltip="true" />
    <el-table-column label="名称（繁体）" align="center" prop="name_zh_tw" :show-overflow-tooltip="true" />
    <el-table-column label="名称（英文）" align="center" prop="name_en_us" :show-overflow-tooltip="true" />
    <el-table-column label="icon" align="center" prop="logoUrl" :show-overflow-tooltip="true">
      <template #default="scope">
        <img v-if="scope.row.picture" :src="scope.row.picture" style="width: 50px; height: 50px" />
      </template>
    </el-table-column>
    <el-table-column label="操作" align="center" width="150" class-name="small-padding fixed-width">
      <template #default="scope">
        <el-button
          link
          type="primary"
          icon="Edit"
          @click="handleUpdate(scope.row)"
          v-hasPermi="['system:config:edit']"
        >修改</el-button>
        <el-button
          link
          type="primary"
          icon="Delete"
          @click="handleDelete(scope.row)"
          v-hasPermi="['system:config:remove']"
        >删除</el-button>
      </template>
    </el-table-column>
  </el-table>

  <pagination
    v-show="total > 0"
    :total="total"
    v-model:page="queryParams.pageNum"
    v-model:limit="queryParams.pageSize"
    @pagination="getList"
  />

  <!-- 添加或修改种类配置对话框 -->
  <el-dialog :title="title" v-model="open" width="500px" append-to-body>
    <el-form ref="configRef" :model="form" :rules="rules" label-width="110px">
      <el-form-item label="名称（简体）" prop="name">
        <el-input v-model="form.name" placeholder="请输入种类名称" />
      </el-form-item>
      <el-form-item label="名称（繁体）" prop="name_zh_tw">
        <el-input v-model="form.name_zh_tw" placeholder="请输入种类键名" />
      </el-form-item>
      <el-form-item label="名称（英文）" prop="name_en_us">
        <el-input v-model="form.name_en_us" placeholder="请输入种类键值" />
      </el-form-item>
      <el-form-item label="配置图片" prop="picture">
        <ImageUpload :limit="1" :fileType="['png', 'jpg']" v-model:modelValue="form.picture" />
      </el-form-item>
      <el-form-item label="配置模块" prop="picture">
        <el-select
          v-model="form.formIds"
          filterable
          remote
          reserve-keyword
          :placeholder="$t('userIndex.search')"
          :remote-method="remoteMethod"
          :loading="loading"
          style="margin-bottom: 20px; width: 100%"
          :clearable="true"
          :multiple="true"
        >
          <el-option
            v-for="item in options"
            :key="item.value"
            :label="item.formName"
            :value="item.id"
          >
            <div class="form_main">
              <div>
                <div>{{ useLang(item, "formName") }}</div>
              </div>
            </div>
          </el-option>
        </el-select>
      </el-form-item>
    </el-form>
    <template #footer>
      <div class="dialog-footer">
        <el-button type="primary" @click="submitForm">确 定</el-button>
        <el-button @click="cancel">取 消</el-button>
      </div>
    </template>
  </el-dialog>
</template>

<script setup name="Config">
import {
  listConfig,
  getConfig,
  delConfig,
  addConfig,
  updateConfig,
  refreshCache,
  selbasicConfigList,
  addbasicConfigList,
  updbasicConfigList,
  selbasicConfigitems,
  delbasicConfigitems
} from "@/api/system/config";
import { selSeverList, addServerList } from "@/api/system/tps";
import { listForm } from "@/api/tps/platform";
import { useLang } from "@/utils/lang.js";

const { proxy } = getCurrentInstance();
const { sys_yes_no } = proxy.useDict("sys_yes_no");

const configList = ref([]);
const open = ref(false);
const loading = ref(true);
const showSearch = ref(true);
const ids = ref([]);
const single = ref(true);
const multiple = ref(true);
const total = ref(0);
const title = ref("");
const dateRange = ref([]);

const data = reactive({
  form: {},
  queryParams: {
    pageNum: 1,
    pageSize: 10,
    type: 2
  },
  rules: {
    name: [
      { required: true, message: "名称（简体）不能为空", trigger: "blur" }
    ],
    name_zh_tw: [
      { required: true, message: "名称（繁体）不能为空", trigger: "blur" }
    ],
    name_en_us: [
      { required: true, message: "名称（英文）不能为空", trigger: "blur" }
    ]
  }
});

const { queryParams, form, rules } = toRefs(data);
const options = ref([]);

/** 查询种类列表 */
function getList() {
  loading.value = true;
  remoteMethod();
  selbasicConfigList(
    proxy.addDateRange(queryParams.value, dateRange.value)
  ).then(response => {
    configList.value = response.rows;
    total.value = response.total;
    loading.value = false;
  });
}

function remoteMethod(val) {
  listForm().then(res => {
    // console.log("res", res);
    options.value = res.rows;
  });
}
/** 取消按钮 */
function cancel() {
  open.value = false;
  reset();
}
/** 表单重置 */
function reset() {
  proxy.resetForm("configRef");
}
/** 搜索按钮操作 */
function handleQuery() {
  queryParams.value.pageNum = 1;
  getList();
}
/** 重置按钮操作 */
function resetQuery() {
  dateRange.value = [];
  proxy.resetForm("queryRef");
  handleQuery();
}
/** 多选框选中数据 */
function handleSelectionChange(selection) {
  ids.value = selection.map(item => item.id);
  single.value = selection.length != 1;
  multiple.value = !selection.length;
}
/** 新增按钮操作 */
function handleAdd() {
  reset();
  open.value = true;
  title.value = "添加种类";
}
/** 修改按钮操作 */
function handleUpdate(row) {
  reset();
  // const configId = row.id || ids.value;
  form.value = Object.assign({}, row);
  open.value = true;
  title.value = "修改种类";
  // selbasicConfigitems(configId).then(response => {
  //   form.value = response.data;
  //   open.value = true;
  //   title.value = "修改种类";
  // });
}
/** 提交按钮 */
function submitForm() {
  proxy.$refs["configRef"].validate(valid => {
    if (valid) {
      form.value.type = 2;
      if (form.value.id != undefined) {
        updbasicConfigList(form.value).then(response => {
          proxy.$modal.msgSuccess("修改成功");
          open.value = false;
          getList();
        });
      } else {
        addbasicConfigList(form.value).then(response => {
          proxy.$modal.msgSuccess("新增成功");
          open.value = false;
          getList();
        });
      }
    }
  });
}
/** 删除按钮操作 */
function handleDelete(row) {
  const configIds = row.id || ids.value;
  proxy.$modal
    .confirm('是否确认删除种类编号为"' + configIds + '"的数据项？')
    .then(function() {
      return delbasicConfigitems(configIds);
    })
    .then(() => {
      getList();
      proxy.$modal.msgSuccess("删除成功");
    })
    .catch(e => {
      console.log(e);
    });
}
/** 导出按钮操作 */
function handleExport() {
  proxy.download(
    "system/config/export",
    {
      ...queryParams.value
    },
    `config_${new Date().getTime()}.xlsx`
  );
}
/** 刷新缓存按钮操作 */
function handleRefreshCache() {
  refreshCache().then(() => {
    proxy.$modal.msgSuccess("刷新缓存成功");
  });
}

getList();
</script>
