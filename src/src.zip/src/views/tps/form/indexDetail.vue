<template>
  <div class="app-container">
    <el-form :model="form" label-width="80px">
      <!-- <el-row>
        <el-col :span="8" :offset="2">
          <el-form-item label="用户昵称" prop="nickName">
            <el-input v-model="form.nickName" disabled />
          </el-form-item>
        </el-col>
        <el-col :span="8" :offset="2">
          <el-form-item label="登录账号" prop="userName">
            <el-input v-model="form.userName" disabled />
          </el-form-item>
        </el-col>
      </el-row>-->
    </el-form>
  </div>
</template>

<script setup>
const form = ref({
  name: "测试表单"
});
</script>

<style>
</style>