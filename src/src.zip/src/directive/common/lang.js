// export const useLang = (obj, attr) => {
//     return 111
// }
import { getLanguage, setLanguage } from "@/utils/lang";
import i18n from "@/lang/index";

export default {
    mounted(el, binding, vnode) {
        const attr = binding.arg;
        const obj = binding.value;
        // const lang = getLanguage();
        const lang = i18n.global.locale.value;
        switch (lang) {
            case 'en-US':
                el.textContent = binding.value[attr + '_en_us'];
                break
            case "zh-TW":
                el.textContent = binding.value[attr + '_zh_tw'];
                break
        }
        // el.textContent = binding.value;
        // console.log('lang', el, binding, vnode)
        // console.log('locale', i18n.global.locale.value)
    }
}