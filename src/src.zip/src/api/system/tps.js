import request from '@/utils/request'

export function selSeverList(query) {
  return request({
    url: '/_1xx/tps_server/list',
    method: 'get',
    params: query
  })
}

export function addServerList(data) {
  return request({
    url: '/_1xx/tps_server',
    method: 'post',
    data
  })
}