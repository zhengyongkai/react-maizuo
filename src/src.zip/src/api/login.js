import request from '@/utils/request'

// 登录方法
export function login(username, password, code, uuid) {
  const data = {
    username,
    password,
    code,
    uuid
  }
  return request({
    url: '/login',
    headers: {
      isToken: false
    },
    method: 'post',
    data: data
  })
}

// 注册方法
export function register(data) {
  return request({
    url: '/register',
    headers: {
      isToken: false
    },
    method: 'post',
    data: data
  })
}

// 获取用户详细信息
export function getInfo() {
  return request({
    url: '/getInfo',
    method: 'get'
  })
}
// 保存用户信息
export function saveInfo(data) {
  return request({
    url: '/getInfo',
    method: 'post',
    data: data
  })
}

// 退出方法
export function logout() {
  return request({
    url: '/logout',
    method: 'post'
  })
}

// 获取验证码
export function getCodeImg() {
  return request({
    url: '/captchaImage',
    headers: {
      isToken: false
    },
    method: 'get',
    timeout: 20000
  })
}


//获取sso登录地址
export function getLoginUrl() {
  return request({
    url: '/social-auth-redirect?type=20',
    headers: {
      isToken: false
    },
    method: 'get',
    timeout: 20000
  })
}

//sso登录获取token
export function socialLogin(params) {
  return request({
    url: '/social-login',
    headers: {
      isToken: false
    },
    method: 'post',
    data: params,
    timeout: 20000
  })
}

