import request from '@/utils/request'


// 查询树结构
export function findFormTree(data) {
    return request({
        url: '/_1xx/find_form/tree',
        method: 'get',
        params: data
    })
}


// 查询系统
export function listFindForm(data) {
    return request({
        url: '/_1xx/find_form/list',
        method: 'get',
        params: data
    })
}

//新增
export function addFindForm(data) {
    return request({
        url: '/_1xx/find_form',
        method: 'post',
        data: data
    })
}

//修改
export function editFindForm(data) {
    return request({
        url: '/_1xx/find_form',
        method: 'put',
        data: data
    })
}
// 刪除
export function delFindForm(ids) {
    return request({
        url: '/_1xx/find_form/' + ids,
        method: 'delete'
    })
}