import request from '@/utils/request'


// 查询系统
export function listPlatForm(data) {
    return request({
        url: '/_1xx/tps_server/list',
        method: 'get',
        params: data
    })
}


// 新增系统
export function addPlatForm(data) {
    return request({
        url: '/_1xx/tps_server',
        method: 'post',
        data: data
    })
}

//修改系统配置
export function editPlatForm(data) {
    return request({
        url: '/_1xx/tps_server',
        method: 'put',
        data: data
    })
}

//删除系统配置
export function delPlatForm(ids) {
    return request({
        url: '/_1xx/tps_server/' + ids,
        method: 'delete'
    })
}






// 查询系统表单
export function listForm(data) {
    return request({
        url: '/_1xx/tps_pc_form/list',
        method: 'get',
        params: data
    })
}


// 新增系统
export function addForm(data) {
    return request({
        url: '/_1xx/tps_pc_form',
        method: 'post',
        data: data
    })
}

//修改系统配置
export function editForm(data) {
    return request({
        url: '/_1xx/tps_pc_form',
        method: 'put',
        data: data
    })
}

//删除系统配置
export function delForm(ids) {
    return request({
        url: '/_1xx/tps_pc_form/' + ids,
        method: 'delete'
    })
}


//查询主页系统加表单
export function getMainPlatForm(data) {
    return request({

        url: '/_1xx/tps_pc_form/list_with_server',
        method: 'get',
        headers: {
            isToken: false
        },
        data: data
    })
}

// 查询系统code
export function getServerCode(params) {
    return request({
        url: '/_1xx/tps_server/gen_code',
        method: 'get',
        params: params
    })
}