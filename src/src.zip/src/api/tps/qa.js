import request from '@/utils/request'


// 查询树结构
export function getQaTree(data) {
    return request({
        url: '/_1xx/qa/tree',
        method: 'get',
        params: data
    })
}

// 查询
export function getListQa(data) {
    return request({
        url: '/_1xx/qa/list',
        method: 'get',
        params: data
    })
}

//查询明细
export function getQaDetail(id) {
    return request({
        url: '/_1xx/qa/' + id,
        method: 'get',

    })
}


//新增
export function addQaTree(data) {
    return request({
        url: '/_1xx/qa',
        method: 'post',
        data: data
    })
}

//修改
export function editQaTree(data) {
    return request({
        url: '/_1xx/qa',
        method: 'put',
        data: data
    })
}
// 刪除
export function delQaTree(ids) {
    return request({
        url: '/_1xx/qa/' + ids,
        method: 'delete'
    })
}
