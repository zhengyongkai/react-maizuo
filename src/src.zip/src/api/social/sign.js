import request from '@/utils/socialRequest'



// 获取待办统计信息
export function getSignTotal(data) {
    return request({
        url: '/unifiedplatform/login/getUnhandle',
        method: 'get',
        params: data
    })
}

//获取待签核列表
export function getSignList(data) {
    return request({
        url: '/unifiedplatform/userInfo/getTaskList',
        method: 'get',
        params: data
    })
}


// 批量签核
export function batchSign(data) {
    return request({
        url: '/unifiedplatform/sign/batchSign',
        method: 'post',
        data: data
    })
}