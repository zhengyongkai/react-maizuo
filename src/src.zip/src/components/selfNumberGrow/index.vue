<template>
  <span :style="customStyle">{{num}}</span>
</template>

<script setup>
import { defineProps } from "vue";

const props = defineProps({
  startVal: {
    type: Number
  },
  endVal: {
    type: Number
  },
  duration: {
    type: Number
  },
  customStyle: {
    type: String
  }
});

const num = ref(0);
num.value = props.startVal;
console.log("aaa", props.duration / (props.endVal - props.startVal));
let interval = setInterval(() => {
  num.value++;
  if (num.value === props.endVal) {
    clearInterval(interval);
  }
}, props.duration / (props.endVal - props.startVal));
</script>

<style>
</style>