<template>
  <div>
    <el-tooltip :content="contentValue" v-if="contentValue">
      <div class="ellipsis">{{textValue}}</div>
    </el-tooltip>

    <div v-else class="ellipsis">{{textValue}}</div>
  </div>
</template>

<script setup>
import { defineProps } from "vue";

const props = defineProps({
  contentValue: {
    type: String
  },
  textValue: {
    type: String
  }
});
</script>

<style lang='scss' scoped>
.ellipsis {
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
  max-width: 100%;
}
</style>