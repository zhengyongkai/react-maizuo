<template>
  <div>
    <el-button plain @click="addClick(item)" type="primary">添加</el-button>
    <div v-for="(item,index) in modelValue" :key="index" class="line">
      <el-input v-model="item.value" @blur="item.name = item.value"></el-input>
      <el-select v-model="item.style" class="m-2" placeholder="选择选项样式" style="margin-left:10px">
        <el-option v-for="it in options" :key="it" :label="it" :value="it" />
      </el-select>

      <el-icon size="20px" color="#f56c6c" style="margin-left:10px" @click="deleteClick(item)">
        <Minus />
      </el-icon>
    </div>
  </div>
</template>

<script setup>
import { defineProps, defineEmits } from "vue";
const { proxy } = getCurrentInstance();
const emits = defineEmits();
const props = defineProps({
  modelValue: {
    default: []
  },
  options: {
    type: Array
  }
});
// const options = ["style1", "style2", "style3", "style4", "style5"];
function addClick(item) {
  var value = props.modelValue;
  if (value) {
    value.push({ name: "", value: "", style: "" });
  } else {
    value = [{ name: "", value: "", style: "" }];
  }
  emits("update:modelValue", value);
}
function deleteClick(item) {
  var value = props.modelValue.filter(it => it.value !== item.value);
  //   if (value.length == 0) {
  //     value = [{ name: "", value: "" }];
  //   }
  //   console.log("value", item, value);
  emits("update:modelValue", value);
}

// console.log("modalValue", props.modalValue);
</script>

<style lang='scss' scoped>
.line {
  display: flex;
  justify-content: flex-start;
  align-items: center;
  margin-top: 10px;
  margin-bottom: 10px;

  .line_option {
  }
}
</style>