import Cookies from 'js-cookie'
// import i18n from "@/lang/index";
const TokenKey = 'lang'

export function getLanguage() {
    return Cookies.get(TokenKey)
}

export function setLanguage(token) {
    return Cookies.set(TokenKey, token, { sameSite: 'Strict' })
}

export function removeLanguage() {
    return Cookies.remove(TokenKey)
}

export function useLang(obj, attr) {
    // const lang = i18n.global.locale.value;
    const lang = getLanguage()
    var value = ''
    switch (lang) {
        case 'en-US':
            value = obj[attr + '_en_us'];
            break
        case "zh-TW":
            value = obj[attr + '_zh_tw'];
            break
        default:
            value = obj[attr];
            break
    }
    // console.log('useLang', lang, value)
    return value
}


