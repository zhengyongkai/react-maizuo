<template>
  <div
    class="header_main"
    :style="route.path == '/social/home'?'background-color: rgba(0, 0, 0, 0.1);color:#fff':''"
  >
    <div class="header_logo">
      <img :src="logoSrc" alt />
      {{$t('system.name')}}
    </div>
    <div class="header_menu" v-show="route.path !== '/social/home'">
      <socialSiber />
    </div>
    <div class="header_op">
      <svg-icon icon-class="question" style="font-size:16px" @click="QaDrawer = true"></svg-icon>
      <svg-icon icon-class="international" style="font-size:16px" @click="LangDrawer = true"></svg-icon>
      <el-drawer
        v-model="LangDrawer"
        :title="$t('userIndex.langTitle')"
        direction="rtl"
        size="302px"
        :append-to-body="true"
      >
        <el-radio-group
          v-model="localeLang"
          class="ml-4"
          @change="langChange"
          style="padding-left:20px;padding-top:20px"
        >
          <el-radio
            style="width:100%"
            v-for="(item,index) in langList"
            :key="index"
            :label="item.value"
            size="large"
          >{{item.name}}</el-radio>
        </el-radio-group>
      </el-drawer>

      <div>
        <div class="avatar-container" v-if="userStore.isLogin">
          <!-- {{userStore.userName}}/{{userStore.realName}} -->
          <el-dropdown trigger="click">
            <div class="avatar-wrapper">
              <img :src="userStore.avatar" class="user_avatar" />
            </div>
            <template #dropdown>
              <el-dropdown-menu>
                <div class="userInfo">
                  <div class="userInfo_content">
                    <img :src="userStore.avatar" class="user_avatar" />
                    <div>
                      <div
                        style="font-size: 20px;font-weight: 600;line-height:22px"
                      >{{userStore.realName}}</div>
                      <div
                        style="font-size:12px;color:#727272;line-height:20px;margin-bottom:20px;margin-top:5px"
                      >{{userStore.userInfo.bg}} {{userStore.userName}}</div>
                      <div v-if="isAdmin" class="userInfo_item">
                        <svg-icon icon-class="managerment"></svg-icon>
                        <el-link
                          :underline="false"
                          @click="toManage"
                          style="color:#4F74C8"
                        >{{$t("userIndex.dropdown1")}}</el-link>
                      </div>
                      <div class="userInfo_item">
                        <svg-icon icon-class="user"></svg-icon>
                        <el-link
                          :underline="false"
                          @click="toUserCenter"
                          style="color:#4F74C8"
                        >{{$t("userIndex.dropdown2")}}</el-link>
                      </div>
                      <div class="userInfo_item">
                        <svg-icon icon-class="logout"></svg-icon>
                        <el-link
                          @click="logout"
                          style="color:#4F74C8"
                          :underline="false"
                        >{{$t("userIndex.dropdown3")}}</el-link>
                      </div>
                    </div>
                  </div>
                  <div style="text-align: center;margin-top:20px">{{$t('system.copyright')}}</div>
                </div>
              </el-dropdown-menu>
            </template>
          </el-dropdown>
        </div>
        <!-- <div v-else>
          <el-link @click="handleLogin">{{$t("login.logIn")}}</el-link>
        </div>-->
      </div>
    </div>

    <el-drawer
      v-model="QaDrawer"
      :title="$t('userIndex.qaTitle')"
      direction="rtl"
      size="498px"
      :append-to-body="true"
    >
      <QA />
    </el-drawer>
  </div>
</template>

<script setup>
import { ElMessageBox } from "element-plus";

import { getLoginUrl } from "@/api/login";
import useUserStore from "@/store/modules/user";
import { getLanguage, setLanguage } from "@/utils/lang";
import { useI18n } from "vue-i18n";
import { getMainPlatForm, listForm } from "@/api/tps/platform";
import { useLang } from "@/utils/lang.js";
import { toOtherSystem } from "@/utils/index.js";
import socialSiber from "./socialSiber";

import QA from "./qa";

const baseUrl = import.meta.env.VITE_APP_BASE_API;
const QaDrawer = ref(false);
const LangDrawer = ref(false);

const { proxy } = getCurrentInstance();

const { locale } = useI18n();

import { useRouter, useRoute } from "vue-router";
const userStore = useUserStore();
const route = useRoute();
const router = useRouter();

const langList = [
  { name: "中文简体", value: "zh-CN" },
  { name: "中文繁體", value: "zh-TW" }
  // { name: "English", value: "en-US" }
];
const isAdmin = computed(() => {
  return userStore.roles.some(user => user === "admin");
});
const lang = ref("zh-cn");

const loading = ref(false);
const options = ref([]);

const searchValue = ref("");
const visibleVal = ref(false);
const localeLang = ref("");

//匹配fsso登录过来后的多语言
const urlLang = new URLSearchParams(window.location.search).get("lang") || "";
lang.value = urlLang || getLanguage();
locale.value = lang.value;
localeLang.value = locale.value;
setLanguage(lang.value);

function langChange(value) {
  if (value) {
    locale.value = value;
    localeLang.value = value;

    window.location.reload();
    setLanguage(value);
    // 获取当前URL的search参数
    const urlParams = new URLSearchParams(window.location.search);
    // 删除lang参数
    urlParams.delete("lang");
  }
}
function handleLogin() {
  getLoginUrl().then(res => {
    if (res) {
      window.open(res.msg, "_self");
    }
  });
}

function toManage() {
  router.push("/index");
}
function toUserCenter() {
  router.push("/social/userCenter");
}
function logout() {
  ElMessageBox.confirm("确定注销并退出系统吗？", "提示", {
    confirmButtonText: "确定",
    cancelButtonText: "取消",
    type: "warning"
  })
    .then(() => {
      userStore.logOut().then(res => {
        // location.href = "/index";
        window.open(res, "_self");
      });
    })
    .catch(() => {});
}
// @/assets/logo/logo.png
const logoSrc = computed(() => {
  if (route.path == "/social/home") {
    switch (lang.value) {
      case "zh-TW":
        return new URL(`@/assets/logo/darkLogo_tw.png`, import.meta.url).href;
        break;
      case "zh-CN":
        return new URL(`@/assets/logo/darkLogo_cn.png`, import.meta.url).href;
        break;
      case "en-US":
        return new URL(`@/assets/logo/darkLogo_us.png`, import.meta.url).href;
        break;
    }
  } else {
    switch (lang.value) {
      case "zh-TW":
        return new URL(`@/assets/logo/lightLogo_tw.png`, import.meta.url).href;
        break;
      case "zh-CN":
        return new URL(`@/assets/logo/lightLogo_cn.png`, import.meta.url).href;
        break;
      case "en-US":
        return new URL(`@/assets/logo/lightLogo_us.png`, import.meta.url).href;
        break;
    }
  }
});
</script>

<style lang='scss' scoped>
::v-deep .el-radio-group {
  display: flex;
  flex-direction: column;
  align-items: flex-start;
}

.header_main {
  width: 100%;
  position: fixed;
  top: 0;
  left: 0;

  padding: 0 24px;
  display: flex;
  justify-content: flex-start;
  align-items: center;
  height: 64px;
  z-index: 999;
  background-color: #fff;
  z-index: 10;

  -webkit-backdrop-filter: blur(10px);
  backdrop-filter: blur(40px);

  // transition: all 0.4s ease;
  // line-height: 100px;
}

.header_logo {
  font-size: 18px;
  font-weight: 700;
  display: flex;
  align-items: center;
  img {
    width: 110px;
    height: 22px;
    margin-right: 10px;
  }
}

.header_menu {
  width: 700px;
  margin-left: 100px;
}

.header_op {
  position: absolute;

  right: 24px;
  display: flex;
  justify-content: flex-end;

  align-items: center;
  line-height: 18px;

  > * {
    margin-left: 20px;
  }
}
.user_avatar {
  cursor: pointer;
  width: 28px;
  height: 28px;
  border-radius: 50%;
}

.userInfo {
  width: 385px;
  height: 227px;
  padding: 20px;
}

.userInfo_content {
  display: flex;

  img {
    width: 50px;
    height: 50px;
  }
  > :first-child {
    margin-right: 20px;
  }
}
.userInfo_item {
  display: flex;
  justify-content: flex-start;
  align-items: center;

  font-size: 14px;
  font-weight: 400;
  line-height: 32px;
  letter-spacing: 0em;

  > :first-child {
    margin-right: 10px;
  }
}
</style>