<template>
  <div class="qBody">
    <div class="qBody_item">{{useLang(valueModel.data[0],'content')}}</div>
  </div>
</template>

<script setup>
import { useLang } from "@/utils/lang.js";

const props = defineProps({
  valueModel: {
    type: Object
  }
});
</script>

<style lang='scss' scoped>
.qBody {
  display: flex;
  justify-content: flex-end;
  margin-bottom: 20px;
}

.qBody_item {
  max-width: 350px;
  background-color: #0249fa;
  border-radius: 5px;
  padding: 10px;
  color: #fff;
  position: relative;
}

.qBody_item::after {
  content: "";
  position: absolute;
  right: -8px;
  top: 12px;
  width: 0;
  height: 0;
  border-top: 8px solid transparent;
  border-bottom: 8px solid transparent;
  border-left: 8px solid #0249fa;
  // transform: rotate(90deg);
}
</style>