<template>
  <div>
    <div class="aMain">
      <img src="@/assets/images/userIndex/qa2.png" alt />
      <div class="aBody">
        <!-- 叶子节点 -->
        <div v-if="checkLeef(valueModel.data)">
          <div class="aBody_item">{{useLang(valueModel.data[0],'content')}}</div>
          <div class="aBody_time">{{valueModel.time}}</div>
        </div>
        <!-- 非叶子节点 -->
        <div v-else>
          <div
            class="aBody_item"
            v-for="(item,index) in valueModel.data"
            :key="index"
            @click="handleClick(item)"
          >
            <span>{{useLang(item,'content')}}</span>
            <el-icon>
              <ArrowRight />
            </el-icon>
          </div>
          <div class="aBody_time">{{valueModel.time}}</div>
        </div>
      </div>
    </div>
    <div class="feedback" v-if="checkLeef(valueModel.data,true)">
      <div @click="feedback('useful')" :class="active=='useful'?'active':''">
        <svg-icon icon-class="useful" style="margin-right:5px" />
        {{$t('userIndex.useful')}}
      </div>
      <div @click="feedback('unuseful')" :class="active=='unuseful'?'active':''">
        <svg-icon icon-class="tab1" style="margin-right:5px" />
        {{$t('userIndex.unuseful')}}
      </div>
    </div>
  </div>
</template>

<script setup>
import { defineProps, defineEmits } from "vue";
import { useLang } from "@/utils/lang.js";

import {
  getQaTree,
  addQaTree,
  editQaTree,
  delQaTree,
  getListQa,
  getQaDetail
} from "@/api/tps/qa";
const { proxy } = getCurrentInstance();

const emit = defineEmits();
const active = ref("");
const props = defineProps({
  valueModel: {
    type: Object
  }
});

function checkLeef(data, feedback) {
  var flag = false;
  if (data && data.length == 1 && data[0].leaf) {
    flag = true;
  }

  if (data[0].feedback && feedback) {
    flag = false;
  }

  return flag;
}

function handleClick(item) {
  console.log("item", item);
  getQaTree({ parentId: item.id }).then(res => {
    // serA(res.data);
    if (res.data.length > 0) {
      emit("setQ", [item]);
      emit("setA", res.data);
    }
  });
}

function feedback(value) {
  active.value = value;
  if (value == "useful") {
    emit("setA", [
      {
        content: proxy.$t("userIndex.usefulContent"),
        feedback: true,
        leaf: true
      }
    ]);
  } else {
    emit("setA", [
      {
        content: proxy.$t("userIndex.unusefulContent"),
        feedback: true,
        leaf: true
      }
    ]);
  }
}
</script>

<style lang='scss' scoped>
.aMain {
  display: flex;
  margin-bottom: 20px;
  img {
    width: 40px;
    height: 40px;
  }

  .aBody {
    background-color: #eee;
    width: 350px;
    border-radius: 5px;
    padding: 0 10px;
    margin-left: 20px;
    position: relative;
  }

  .aBody::after {
    content: "";
    position: absolute;
    left: -8px;
    top: 12px;
    width: 0;
    height: 0;
    border-top: 8px solid transparent;
    border-bottom: 8px solid transparent;
    border-right: 8px solid #eee;
    // transform: rotate(90deg);
  }

  .aBody_item {
    border-bottom: 1px solid #ddd;
    padding: 10px 0;
    display: flex;
    justify-content: space-between;
    align-items: center;
    cursor: pointer;
    white-space: pre-wrap;
  }

  .aBody_time {
    float: right;
    font-size: 12px;
    padding: 10px 0;
    color: rgb(155, 155, 155);
  }
}

.feedback {
  display: flex;
  transform: translateY(-10px);
  justify-content: flex-end;
  padding-right: 40px;

  > * {
    padding: 5px 10px;
  }
  > :first-child {
    border-radius: 10px 0 0 10px;
    // color: #0249fa;
    // background-color: rgb(2, 73, 250, 0.15);
    color: #808080;
    background-color: #eee;
    cursor: pointer;
  }

  > :last-child {
    border-radius: 0 10px 10px 0;
    color: #808080;

    background-color: #eee;
    margin-left: 10px;
    cursor: pointer;
  }

  .active {
    color: #fff !important;
    background-color: #0249fa !important;
  }
}
</style>