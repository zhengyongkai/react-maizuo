<template>
  <div class="mqMain">
    <div class="qa">
      <div class="qaContent" ref="qaContentRef">
        <div v-for="(qa,index) in qaList" :key="index">
          <component
            :is="qa.type == 'answer' ? answer:question"
            :valueModel="qa"
            @setA="setA"
            @setQ="setQ"
          ></component>
        </div>
      </div>
      <div class="qaAsk">
        <el-popover placement="top" :width="400" :visible="visibleVal">
          <template #reference>
            <el-input
              v-model="searchValue"
              class="w-50 m-2"
              :placeholder="$t('userIndex.search')"
              @blur="visibleVal=false"
              @keydown.enter="remoteMethod"
              size="large"
            >
              <template #suffix>
                <svg-icon icon-class="send" @click="remoteMethod" />
              </template>
            </el-input>
          </template>
          <el-row
            class="search_item"
            v-for="(item,index) in options"
            :key="index"
            @click="handleClick(item)"
          >{{useLang(item,'content')}}</el-row>
          <el-row
            v-if="!options || options.length == 0"
            style="justify-content: center;"
          >{{$t('system.empty')}}</el-row>
        </el-popover>
      </div>
    </div>
  </div>
</template>

<script setup>
const popoverRef = ref();
const visible = ref(false);
const qaList = ref([]);
const { proxy } = getCurrentInstance();
import { useLang } from "@/utils/lang.js";

import {
  getQaTree,
  addQaTree,
  editQaTree,
  delQaTree,
  getListQa,
  getQaDetail
} from "@/api/tps/qa";

import answer from "./qaCom/answer";
import question from "./qaCom/question";
const searchValue = ref("");
const visibleVal = ref(false);
const options = ref([]);
function onClickOutside() {
  //   console.log(" unref(popoverRef)", unref(popoverRef), popoverRef.value);
  //   popoverRef.value.popperRef.delayHide();
  visible.value = true;
}

function init() {
  getQaTree({ parentId: 0 }).then(res => {
    setA(res.data);
  });
}

function setQ(data) {
  qaList.value.push({
    type: "question",
    data: data,
    time: proxy.moment().format("YYYY/MM/DD hh:mm")
  });

  console.log("qaList", qaList.value);
}

function setA(data) {
  qaList.value.push({
    type: "answer",
    data: data,
    time: proxy.moment().format("YYYY/MM/DD hh:mm")
  });

  nextTick(() => {
    const qaContentRef = proxy.$refs["qaContentRef"];
    if (qaContentRef) {
      qaContentRef.scrollTop = qaContentRef.scrollHeight;
    }
    // console.log("qaList", qaContentRef.scrollHeight);
  });
}

function checkLeef(data) {
  var flag = false;
  if (data && data.length == 1 && data[0].leaf) {
    return true;
  }
}

function remoteMethod(val) {
  console.log(searchValue);
  if (searchValue.value) {
    visibleVal.value = true;
    getListQa({ keyword: searchValue.value }).then(res => {
      // console.log("res", res);
      options.value = res.data;
    });
  } else {
    options.value = [];
  }
}
function handleClick(item) {
  getQaTree({ parentId: item.id }).then(res => {
    // serA(res.data);
    if (res.data.length > 0) {
      setQ([item]);
      setA(res.data);
    }

    visibleVal.value = false;
  });
}
init();
</script>

<style lang='scss' scoped>
.mqMain {
  color: #000;
  img {
    width: 80px;
    height: 80px;
  }
}

.qa {
  width: 500px;
  // box-shadow: 0 2px 4px rgba(0, 0, 0, 0.2);
  // border: 1px solid #ddd;
  //   height: 400px;

  .qaTitle {
    display: flex;
    align-items: center;
    justify-content: space-between;
    height: 30px;
    color: #fff;
    padding: 20px 20px;
    // background: url("../../../assets/images/QATitle.png");
    background-image: url("../../../src/assets/images/userIndex/QATitle.png");
    background-repeat: no-repeat;
    // background-position: center;
    background-size: cover;
    // background-attachment: fixed;

    // background-color: blue;
  }

  .qaContent {
    background-color: #fff;
    height: calc(100vh - 80px);
    padding: 20px;
    overflow-y: auto;
  }

  .qaAsk {
    // height: 30px;
    // border-top: 1px solid rgb(207, 207, 207);
    width: 100%;
    position: absolute;
    bottom: 0;
    right: 0;
    background-color: #fff;
  }
}

.search_item {
  border-bottom: 1px solid #ddd;
  padding: 10px 0;
  display: flex;
  justify-content: space-between;
  align-items: center;
  cursor: pointer;
  white-space: pre-wrap;
}
</style>