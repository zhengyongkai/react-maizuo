<template>
  <div class="siberMain">
    <el-scrollbar :class="sideTheme" wrap-class="scrollbar-wrapper">
      <el-menu
        :default-active="activeMenu"
        :unique-opened="true"
        mode="horizontal"
        background-color="transparent"
        active-text-color="#4F74C8"
      >
        <sidebar-item
          v-for="(route, index) in userSidebarRouters"
          :key="route.path + index"
          :item="route"
          :base-path="route.path"
        />
      </el-menu>
    </el-scrollbar>
  </div>
</template>

<script setup>
import SidebarItem from "./SidebarItem";
import usePermissionStore from "@/store/modules/permission";
const permissionStore = usePermissionStore();
const route = useRoute();
const userSidebarRouters = computed(() => permissionStore.userSidebarRouters);
console.log("userSidebarRouters", userSidebarRouters);
const activeMenu = computed(() => {
  const { meta, path } = route;
  // if set path, the sidebar will highlight the path you set
  if (meta.activeMenu) {
    return meta.activeMenu;
  }
  return path;
});
</script>

<style lang='scss' scoped>
::v-deep .el-menu-item {
  font-size: 14px;
  font-weight: 400;
  height: 40px;
  line-height: 40px;
}
::v-deep .menu-title {
  height: 100%;
}

::v-deep .el-menu--horizontal .el-menu-item:not(.is-disabled):hover {
  color: #4f74c8 !important;
  background: transparent;
}
::v-deep .el-menu--horizontal .el-menu-item:not(.is-disabled):focus {
  color: #4f74c8 !important;
  background: transparent;
}

::v-deep .el-menu--horizontal {
  border: none;
  // height: 100%;
  justify-content: flex-start;
}
.siberMain {
  height: 40px;
  // width: 100%;
  // background-color: #eceff4;
  // height: 60px;
}
</style>