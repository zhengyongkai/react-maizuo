<template>
  <div class="footmain">
    <span>{{$t('system.copyright')}}</span>
  </div>
</template>

<script>
</script>

<style lang='scss' scoped>
.footmain {
  // position: absolute;
  // bottom: 0;
  // left: 0;
  width: 100vw;
  height: 50px;
  // background-color: #f3f3f3;
  // background-color: #fbfbfb;
  background: transparent;

  text-align: center;
  font-size: 12px;
  line-height: 50px;
}
</style>