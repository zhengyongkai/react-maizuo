<template>
  <div class="main">
    <socialHeader />
    <!-- <socialSiber /> -->
    <router-view class="content"></router-view>

    <socialFoot />
    <!-- <QA></QA> -->
  </div>
</template>

<script setup>
import Cookies from "js-cookie";
import socialFoot from "./components/socialFoot";
import socialHeader from "./components/socialHeader";
import socialSiber from "./components/socialSiber";
import useUserStore from "@/store/modules/user";
import QA from "./components/qa";
import { getToken, setToken, removeToken } from "@/utils/auth";

const userStore = useUserStore();
const router = useRouter();
const route = useRoute();
//sso登录返回的code
const code = ref("");
// fsso登录返回的key
const key = ref("");
const data = ref("");

function init() {
  // 用户端设置接口使用lang
  Cookies.set("useLang", true, { sameSite: "Strict" });

  const urlParams = new URLSearchParams(window.location.search);
  code.value = urlParams.get("code") || "";
  key.value = urlParams.get("key")
    ? encodeURIComponent(urlParams.get("key"))
    : "";
  data.value = encodeURIComponent(urlParams.get("data")) || "";

  alert(code.value);

  if (code.value || key.value) {
    var loginVal = {
      type: 20,
      code: "code",
      state: ""
    };
    if (code.value && code.value != "") {
      loginVal.type = 20;
      loginVal.code = code.value;
    }
    if (key.value && key.value != "") {
      loginVal.type = 30;
      loginVal.code = key.value;
      loginVal.state = data.value;
    }
    userStore
      .login(loginVal)
      .then(() => {
        router.push({ path: route.path });
      })
      .catch(() => {
        // loading.value = false;
      });
  }
}
init();
</script>

<style lang='scss' >
.main {
  width: 100vw;
  position: relative;
  height: auto;
}

.content {
  min-height: calc(100vh - 50px);
}

::-webkit-scrollbar {
  width: 0px;
  height: 6px;
}

::-webkit-scrollbar-track {
  background-color: #f1f1f1;
}

::-webkit-scrollbar-thumb {
  background-color: #c0c0c0;
  border-radius: 3px;
}
</style>