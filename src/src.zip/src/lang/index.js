import { createI18n } from "vue-i18n"; // import from runtime only
// eslint-disable-next-line @typescript-eslint/ban-ts-comment
// @ts-ignore
import { getLanguage, setLanguage } from "@/utils/lang";

// eslint-disable-next-line @typescript-eslint/ban-ts-comment
// @ts-ignore
// import elementEnLocale from "element-plus/lib/locale/lang/en";
// eslint-disable-next-line @typescript-eslint/ban-ts-comment
// @ts-ignore
// import elementZhLocale from "element-plus/lib/locale/lang/zh_cn";
// User defined lang
import en_us from "./en-us/en-us.js";
import zh_cn from "./zh-cn/zh-cn.js";
import zh_tw from './zh-tw/zh-tw.js'

const messages = {
    'en-US': {
        ...en_us,
        // ...elementEnLocale,
    },
    "zh-CN": {
        ...zh_cn,
        // ...elementZhLocale,
    },
    "zh-TW": {
        ...zh_tw
    }
};

export const getLocale = () => {
    //读取cookie存入的当前语言
    const cookieLanguage = getLanguage();
    //如果有返回当前语言
    if (cookieLanguage) {
        return cookieLanguage;
    }
    //如果没有，获取系统语言
    // const language = navigator.language.toLowerCase();
    const language = 'zh-CN'
    if (language) {
        setLanguage(language)
    }
    //获取messages 语言 遍历
    const locales = Object.keys(messages);
    for (const locale of locales) {
        //如果messsage 包里面有系统语言返回
        if (language.indexOf(locale) > -1) {
            return locale;
        }
    }
    // 默认语言 简体中文
    return 'zh-CN'
};


const i18n = createI18n({
    globalInjection: true,
    legacy: false,
    locale: getLocale(),
    messages: messages,
});

export default i18n;
