export default {
    name: "IT Service Integartion System",
    copyright: 'Copyright © 2023 Hon Hai Precision Industry Co., Ltd',
    save: 'save',
    saveInfo: 'Save successfully！',
    empty: 'No Data'


};