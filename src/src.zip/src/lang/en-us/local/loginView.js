export default {
    logIn: "Login",
    entry1: 'InfoService',
    entry2: 'home'
};