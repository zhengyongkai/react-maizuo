
import login from './local/loginView'
import system from './local/system'
import userIndex from './social/userIndex'
import sign from './social/sign'
import userCenter from './social/userCenter'
import home from './social/home'

export default {
    'system': system,
    'login': login,
    "userIndex": userIndex,
    "sign": sign,
    "userCenter": userCenter,
    "home": home

};