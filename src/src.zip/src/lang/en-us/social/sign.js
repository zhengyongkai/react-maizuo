export default {
    tab1: "PendingSummary",
    tab2: 'PendingList',
    tab3: 'MyForm',
    content: 'PendingApproval',
    docName: 'DocName',
    docNo: 'DocNo',
    lastSignTime: 'LastSignTime',
    signNode: 'SignNode',
    creater: 'creater',
    option: 'Option',
    sys: 'System',
    batchSign: 'BatchSign',
    batchReject: 'BatchReject',
    title: 'Please enter your opinion',
    confirm: 'Confirm',
    cancel: 'Cancel',
    view: 'view'

};