export default {
    group: "UserGroup",
    tags: 'Tags',
    attRequire: 'Attachment',
    type: 'Type',
    search: 'Please enter the item you want to search...',

    dropdown1: 'Management',
    dropdown2: 'UserCenter',
    dropdown3: 'LoginOut',

    tooltip: 'Unable to find the service orm, ask us a question.',
    qaTitle: 'Smart Q&A',
    useful: 'Useful',
    unuseful: 'Useless',
    usefulContent: 'Thank you for your comments on this service!',
    unusefulContent: 'Unfortunately, this time we are unable to provide a good IT service, you can call the hotline 560-106！',
    langTitle: 'Language setting'

};