export default {
    title1: '用心为您，一站到位，全面满足您对资讯服务的需求',
    welcome: '欢迎回来！',
    formInfo: '您有$1笔待办签核，$2笔被退回的申请，$3笔草稿待提交',
    toWork: '前往工作台',
    loginInfo1: '请使用相信APP',
    loginInfo2: '扫码快速登入',
    loginInfo3: '改以其它方式登入',



};