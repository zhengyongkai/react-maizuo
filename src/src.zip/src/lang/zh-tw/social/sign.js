export default {
    tab1: "待審核匯總",
    tab2: '待審核明細',
    tab3: '我的申請單',
    content: '待審批單據',
    docName: '單據名稱',
    docNo: '單據編號',
    lastSignTime: '最新簽核時間',
    signNode: '簽核節點名稱',
    creater: '承辦人',
    option: '操作',
    sys: '系統',
    batchSign: '批量通過',
    batchReject: '批量拒絕',
    title: '請輸入簽核意見',
    confirm: '確認',
    cancel: '取消',
    view: '查看'

};