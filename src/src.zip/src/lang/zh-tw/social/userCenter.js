export default {
    tab1: "員工個人信息",
    tab2: '員工單位信息',

    userName: "用戶賬號/工號",
    realName: '姓名',
    sex: '性別',
    phoneNumber: '電話',
    birthdate: '生日',
    eduDegree: '學歷',
    hireDate: '入職日期',
    company: '法人',
    email: '郵箱',
    subOrg: '次集團',
    bg: '事業群',
    bu: '事業處',
    costCode: '費用代碼',
    country: '國家/地區',
    area: '廠區',
    jobTitle: '職位',
    gradeDepart: '所屬技委會',
    grade: '職係',
    class: '資位',
    jobStatus: '在職狀態',

    tel1: '大陸分機',
    tel2: '台灣分機',
    tel3: '香港分機',
    tel4: '海外分機',
    save: '保存'

};