export default {
    group: "申請用戶群",
    tags: '標籤',
    attRequire: '附件要求',
    type: '業務類別',
    search: '請輸入想搜索的項目...',
    dropdown1: '管理端',
    dropdown2: '檢視個人中心',
    dropdown3: '登出',


    tooltip: '找不到服務表單？向我們提問吧！',
    qaTitle: '智能問答',
    useful: '有用',
    unuseful: '無用',
    usefulContent: '感謝您對本次服務的評價！',
    unusefulContent: '很遺憾，本次未能提供很好的服務，您可撥打熱線560-106聯繫人工客服處理！',
    langTitle: '語言設定'



};