export default {
    title1: '用心為您，一站到位，全面滿足您對資訊服務的需求',
    welcome: '歡飲回來！',
    formInfo: '您有$1筆待辦簽核，$2筆被退回的申請，$3筆草稿待提交',
    toWork: '前往工作台',
    loginInfo1: '請使用相信APP',
    loginInfo2: '掃碼快速登入',
    loginInfo3: '改以其它方式登入',



};