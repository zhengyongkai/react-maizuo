export default {
    name: 'IT服務整合系統',
    copyright: 'Copyright © 2023 鴻海精密工業股份有限公司',
    save: '保存',
    saveInfo: '保存成功！',
    empty: '無數據'
}