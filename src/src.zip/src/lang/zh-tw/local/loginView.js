export default {
    logIn: "登錄",
    entry1: '資訊服務',
    entry2: '首頁'
};