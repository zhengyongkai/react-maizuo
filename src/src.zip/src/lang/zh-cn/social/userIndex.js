export default {
    group: "申请用户群",
    tags: '标签',
    attRequire: '附件要求',
    type: '业务类别',
    search: '请输入想搜索的项目...',
    dropdown1: '管理端',
    dropdown2: '检视个人中心',
    dropdown3: '登出',



    tooltip: '找不到服务表单？向我们提问吧！',
    qaTitle: '智能问答',
    useful: '有用',
    unuseful: '无用',
    usefulContent: '感谢您对本次服务的评价！',
    unusefulContent: '很遗憾，本次未能提供很好的IT服务，您可拨打热线560-106联系人工客服处理！',
    langTitle: '语言设定'




};