export default {
    tab1: "员工个人信息",
    tab2: '员工单位信息',

    userName: "用戶账号/工号",
    realName: '姓名',
    sex: '性别',
    phoneNumber: '电话',
    birthdate: '生日',
    eduDegree: '学历',
    hireDate: '入职日期',
    company: '法人',
    email: '邮箱',
    subOrg: '次集团',
    bg: '事业群',
    bu: '事业处',
    costCode: '费用代码',
    country: '国家/地区',
    area: '厂区',
    jobTitle: '职位',
    gradeDepart: '所属技委会',
    grade: '职系',
    class: '资位',
    jobStatus: '在职状态',

    tel1: '大陆分机',
    tel2: '台湾分机',
    tel3: '香港分机',
    tel4: '海外分机',
    save: '保存'



};