export default {
    tab1: "待审核汇总",
    tab2: '待审核明细',
    tab3: '我的申请单',
    content: '待审批单据',
    docName: '单据名称',
    docNo: '单据编号',
    lastSignTime: '最新签核时间',
    signNode: '签核节点名称',
    creater: '承办人',
    option: '操作',
    sys: '系统',
    batchSign: '批量通过',
    batchReject: '批量拒绝',
    title: '请输入签核意见',
    confirm: '确认',
    cancel: '取消',
    view: '查看'


};