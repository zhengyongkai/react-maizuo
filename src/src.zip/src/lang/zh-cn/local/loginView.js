export default {
    logIn: "登录",
    entry1: '资讯服务',
    entry2: '首页'
};