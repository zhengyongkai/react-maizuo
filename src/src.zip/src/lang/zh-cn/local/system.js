export default {
    name: 'IT服务整合系统',
    copyright: 'Copyright © 2023 鸿海精密工业股份有限公司',
    save: '保存',
    saveInfo: '保存成功！',
    empty: '无数据'

}