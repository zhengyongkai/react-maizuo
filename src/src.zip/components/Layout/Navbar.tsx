import { NavBar } from "antd-mobile";

export default () => {
  return <NavBar>标题</NavBar>;
};
