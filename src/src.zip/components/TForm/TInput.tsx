import React from "react";

export default function TInput(props) {
  return (
    <>
      <div>
        <label>{props.xxxx}</label>
        <input></input>
      </div>
    </>
  );
}
