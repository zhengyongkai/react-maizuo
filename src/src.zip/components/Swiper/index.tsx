import {Component} from "react";
interface AppProps {
  
}
 
interface AppState {
  
}
 
class App extends Component<AppProps, AppState> {
  state = {  }
  render() { 
    return (<>
    </>);
  }
}
 
export default App;
