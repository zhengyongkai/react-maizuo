import { memo, useMemo } from "react"

function Page3(){
  return <>
  Page3
  </>
}

export default memo(Page3)