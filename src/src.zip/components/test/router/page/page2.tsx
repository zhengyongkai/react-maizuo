import { memo, useMemo } from "react"

function Page2(){
  return <>
  Page2
  </>
}

export default memo(Page2)