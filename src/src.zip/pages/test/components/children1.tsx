import React from "react";

interface childrenState {}
interface childrenProps {}

const children1: React.FC<childrenProps> = (props) => {
  return <></>;
};

export default children1;
