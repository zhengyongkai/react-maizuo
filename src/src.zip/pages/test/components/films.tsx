import { memo, useEffect, useState } from "react";
import { getMoviceDetail } from "@/pages/api/movice";
import { useParams } from "react-router-dom";

import "@/pages/css/films.scss";

import type { detailsResponseImf, detailsImf } from "@/pages/types/movice";

function FilmPage() {
  const { id } = useParams();

  const [details, setDetails] = useState<detailsImf>();

  async function getDetails() {
    const {
      data: { film },
    } = (await getMoviceDetail({ filmId: id })) as detailsResponseImf;

    setDetails(film);
  }

  useEffect(() => {
    getDetails();
  }, []);

  return (
    <>
      {details ? (
        <div>
          <div className="film-tabbar">{details.name}</div>
          <div className="film-poster">
            <img src={details.poster}></img>
          </div>
          <div className="film-descrption">
            <div>
              {details.name} {details.filmType.name}
            </div>
            <div>{details.category}</div>
            <div></div>
          </div>
        </div>
      ) : null}
    </>
  );
}

export default memo(FilmPage);
