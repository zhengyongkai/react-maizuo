import { memo, useEffect, useState } from "react";
import { getMoviceData, getMoviceComingData } from "@/pages/api/movice";
import { moviceImf } from "@/pages/types/movice";
import "@/pages/css/movice.scss";
import { useParams } from "react-router-dom";
import Loading from "./loading";
import { useSelector } from "react-redux";

import type { cityStateImf } from "@/types/location";
import { InfiniteScroll } from "antd-mobile";

function comingSoon() {
  const [movice, setMovice] = useState<Array<moviceImf>>([]);
  const [hasMore, setHasMore] = useState<boolean>(true);
  const cityId = useSelector(
    (state: cityStateImf) => state.location.locale.cityId
  );
  const [page, setPage] = useState({
    pageNum: 0,
    pageSize: 10,
    total: 0,
    cityId,
  });

  async function getMoviceDataList() {
    const api = getMoviceComingData;
    const {
      data: { films, total },
    } = await api(page);
    if (films.length === 0) {
      return setHasMore(false);
    }
    const list = movice.concat(films);
    setMovice(list);
    setPage({
      ...page,
      total,
    });
  }

  async function loadMore() {
    setPage({
      ...page,
      pageNum: (page.pageNum += 1),
    });
    console.log(page);
    await getMoviceDataList();
  }

  return (
    <>
      <div>
        {movice.map((item, index) => {
          return (
            <div className="movice-item" key={index}>
              <div className="movice-poster">
                <img src={item.poster} alt="" />
              </div>
              <div className="movice-content">
                <div className="movice-name">{item.name}</div>

                <div className="movice-anctor text-ellipsis">
                  {item.actors.map((anctor, index) => {
                    return <span key={index}>{anctor.name} </span>;
                  })}
                </div>
                <div className="movice-tips">
                  <span>{item.nation}</span>
                  <span>|</span>
                  <span>{item.runtime}</span>
                </div>
              </div>
              <div>
                <span>购票</span>
              </div>
            </div>
          );
        })}
        <InfiniteScroll loadMore={loadMore} hasMore={hasMore}></InfiniteScroll>
      </div>
    </>
  );
}

export default memo(comingSoon);
