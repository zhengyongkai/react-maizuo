export const MAIZUO = "https://m.maizuo.com/gateway";
