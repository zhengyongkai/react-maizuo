export interface colorType {}
