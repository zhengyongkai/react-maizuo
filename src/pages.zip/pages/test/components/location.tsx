import "@/pages/css/location.scss";
import { useSelector, useDispatch } from "react-redux";
import { getLocationListsAsyc } from "@/store/common/location";
import { IndexBar, List } from "antd-mobile";
import { useEffect, useState } from "react";

interface cityImf {
  pinyin: string;
  name: string;
}

interface formatImf {
  title: string;
  name: string;
}

function locationPage() {
  const dispatch = useDispatch();
  const city = useSelector((state) => state.location.locale);
  const locationList = useSelector((state) => state.location.locationList);
  const [hotList, setHotList] = useState<Array<{ name: string }>>([]);
  const [list, setList] = useState<
    Array<{ title: string; items: Array<formatImf> }>
  >([]);

  useEffect(() => {
    const formatList = locationList.reduce(
      (
        pre: Map<string, { pinyin: string; list: Array<cityImf> }>,
        res: cityImf
      ) => {
        const chatOne = res.pinyin.charAt(0);
        const lists = (pre.get(res.pinyin.charAt(0))?.list ||
          []) as Array<cityImf>;

        pre.set(chatOne, {
          pinyin: res.pinyin,
          list: [...lists, { pinyin: res.pinyin, name: res.name }],
        });

        return pre;
      },
      new Map()
    ) as Map<string, { pinyin: string; list: Array<cityImf> }>;
    const result = [...formatList.entries()]
      .map((res) => {
        return {
          title: res[0].toLocaleUpperCase(),
          items: res[1].list,
        };
      })
      .sort((a, b) => {
        if (a.title < b.title) {
          return -1;
        }
        if (a.title > b.title) {
          return 1;
        }
        return 0;
      });
    setList(result);
    setHotList(locationList.filter((res) => res.isHot === 1));
  }, [locationList]);
  useEffect(() => {
    if (list.length === 0) {
      dispatch(getLocationListsAsyc());
    }
  }, []);
  return (
    <>
      <div className="city-location">当前城市 - {city} </div>
      <div className="city-recommend">
        <div className="city-title">热门城市</div>
        <div className="city-tabs">
          {hotList.map((item, index) => {
            return (
              <div className="city-tab" key={index}>
                {item.name}
              </div>
            );
          })}
        </div>
      </div>
      <div className="city-list">
        <IndexBar>
          {list.map((group) => {
            const { title, items } = group;
            return (
              <IndexBar.Panel index={title} title={title} key={title}>
                <List>
                  {items.map((item, index) => {
                    return <List.Item key={index}>{item.name}</List.Item>;
                  })}
                </List>
              </IndexBar.Panel>
            );
          })}
        </IndexBar>
      </div>
    </>
  );
}

export default locationPage;
