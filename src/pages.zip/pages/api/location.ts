import request from "@/pages/utils/request";

export function getLocationList() {
  return request.get("https://m.maizuo.com/gateway?k=564058", {
    headers: {
      "X-Host": "mall.film-ticket.city.list",
    },
  });
}
