export interface district {
  districtId: number;
  districtName: string;
}

export interface tude {
  latitude: number;
  longitude: number;
}
