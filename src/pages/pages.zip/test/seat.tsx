export default function seat() {
  return <></>;
}
