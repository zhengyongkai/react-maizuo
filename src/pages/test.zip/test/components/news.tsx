export default function newsPage() {
  return <>news</>;
}
