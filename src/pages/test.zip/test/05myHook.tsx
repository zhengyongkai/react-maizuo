function myHook(token, styleFn) {}

export default myHook("Button", () => {
  return [];
});
